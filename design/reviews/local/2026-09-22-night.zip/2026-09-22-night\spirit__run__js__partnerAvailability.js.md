# spirit/run/js/partnerAvailability.js

Model gpt-oss:120b, 1 slice(s), 5.8 min, 3488 tokens out.

## Lines 1–92

1. [REGRESSION] Future timestamps keep a partner marked unavailable indefinitely.  
   where: spirit/run/js/partnerAvailability.js:38‑53  
   why: `Date.parse` accepts arbitrary dates; `note` stores `atMs` even if far in the future. `unavailable()` checks `now() - w.atMs < QUIET_MS`, which is true for future timestamps, causing a permanent unavailable state.  
   fix: reject or clamp timestamps > `now() + QUIET_MS` before storing.

2. [DESIGN] Unbounded growth of the `byRelay` map can cause memory exhaustion.  
   where: spirit/run/js/partnerAvailability.js:33‑45  
   why: No eviction or size limit; each unique `url`/`relayKey` adds a new entry that persists for the process lifetime, allowing a malicious relay to fill memory.  
   fix: prune entries older than `QUIET_MS` or enforce a maximum map size with LRU eviction.

3. [DESIGN] Use block‑scoped `const`/`let` instead of `var` for immutable values.  
   where: spirit/run/js/partnerAvailability.js:27,29,85‑86  
   why: `var` is function‑scoped and can be re‑assigned, reducing readability and safety; `const`/`let` clarify intent and avoid hoisting issues.  
   fix: replace `var QUIET_MS = …`, `var o = …`, and `var shared = null` with `const`/`let` as appropriate.

4. [DESIGN] Validate `body.at` format and reject non‑ISO strings.  
   where: spirit/run/js/partnerAvailability.js:37‑39  
   why: `Date.parse` accepts many ambiguous formats; allowing malformed dates can lead to inconsistent timestamps and the future‑timestamp issue above.  
   fix: require `body.at` to match ISO‑8601 (`/^\d{4}-\d{2}-\d{2}T…Z$/`) and fallback to `now()` if invalid.

5. [UNVERIFIED] Ensure `note` is only invoked with authenticated broadcast data.  
   where: spirit/run/js/partnerAvailability.js:35‑45  
   why: The function does not verify signatures; if called with unauthenticated input, the availability map could be poisoned.  
   fix: add a comment/assertion that callers must verify signatures, or integrate a verification step before updating the map.
