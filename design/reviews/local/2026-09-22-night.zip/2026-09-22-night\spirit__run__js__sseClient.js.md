# spirit/run/js/sseClient.js

Model gpt-oss:120b, 1 slice(s), 9.6 min, 5952 tokens out.

## Lines 1–366

1. [REGRESSION] spirit/run/js/sseClient.js:152; uses the global `fetch` (fallback when `opts.fetchImpl` is absent), directly performing an HTTP request and bypassing the mandated `peerPost` interface. This violates AGENT.md rules “No component reaches for `fetch`” and “All comms go through `peerPost`”. fix: remove the global‑fetch fallback and require an injected request function (e.g., `opts.peerPostRequest`) that internally uses `peerPost`; abort if not supplied.

2. [DESIGN] spirit/run/js/sseClient.js:345‑354; the comment claims the module “exported five things” while the actual `module.exports` only exposes `connect`. The stale comment can mislead developers and hide the fact that unused symbols were deliberately removed. fix: update the comment to accurately describe the current export surface (only `connect`).
