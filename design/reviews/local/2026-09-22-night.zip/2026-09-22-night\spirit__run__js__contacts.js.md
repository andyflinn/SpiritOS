# spirit/run/js/contacts.js

Model gpt-oss:120b, 1 slice(s), 12.6 min, 7655 tokens out.

## Lines 1–709

1. [REGRESSION] Silent loss of all contacts when the JSON file is malformed or unreadable.  
   where: contacts.js:213‑225  
   why: `load()` catches any `JSON.parse` or file‑read error and returns an empty array, wiping the address book without logging or aborting.  
   fix: Log the error (or rethrow) instead of returning `[]`.

2. [REGRESSION] Errors from mark‑book synchronization are swallowed.  
   where: contacts.js:262‑267  
   why: `syncMarks()` catches all exceptions from `nodeStore.open(...).seen.markBook` and returns `false` without reporting, so failures to sync marks go unnoticed.  
   fix: Log the caught error (or propagate it) rather than silencing it.

3. [DESIGN] Blocking the event loop with synchronous file I/O.  
   where: contacts.js:210‑227 (load) and contacts.js:229‑236 (save)  
   why: `fs.readFileSync`, `fs.writeFileSync`, and `fs.mkdirSync` block Node’s single thread, degrading responsiveness for all concurrent operations.  
   fix: Replace with `fs.promises.readFile`, `fs.promises.writeFile`, and `fs.promises.mkdir` and `await` the calls.

4. [DESIGN] No validation of `rootDir` before constructing file paths, risking path‑traversal or arbitrary‑file access if `rootDir` is ever user‑controlled.  
   where: contacts.js:183, 210, 229 (all uses of `bookPath(rootDir)` and `fs` calls)  
   why: If an attacker can influence `rootDir`, the module could read/write outside the intended `relay-state` directory.  
   fix: Resolve `rootDir` with `path.resolve` and verify it stays within a permitted base directory. UNVERIFIED (cannot confirm the source of `rootDir`).

5. [DESIGN] Stale “routes” helpers that reference a removed `routes` field.  
   where: contacts.js:565‑579 (`routesOf`, `everyRouteHeld`)  
   why: The `routes` property was removed in decision 0018; these functions now only return empty data and add dead code.  
   fix: Delete `routesOf` and `everyRouteHeld` or clearly deprecate them.
