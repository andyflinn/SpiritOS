# spirit/run/js/nodeCard.js

Model gpt-oss:120b, 1 slice(s), 14.0 min, 9139 tokens out.

## Lines 1–310

1. [REGRESSION] Default `at` value erroneously defaults to 1, allowing cards without a proper counter to be accepted.  
   where: spirit/run/js/nodeCard.js:116  
   why: Policy comment (lines 179‑182) requires cards lacking a counter to be refused, but `at: Number(id.cardAt || 1)` gives a positive value, bypassing the `fields.at > 0` check in verify.  
   fix: Change default to `Number(id.cardAt || 0)` (or omit default) so missing counters are rejected.  

2. [REGRESSION] `verify` may throw an uncaught exception if `auth.verify` errors, risking node crash.  
   where: spirit/run/js/nodeCard.js:183  
   why: The call to `auth.verify` is not wrapped in try/catch; a malformed signature could cause `auth.verify` to throw, propagating an exception.  
   fix: Wrap the `auth.verify` call in try/catch and return `null` on error. *(UNVERIFIED – cannot confirm `auth.verify` throws)*  

3. [DESIGN] `verify` does not validate the `ok` flag in the card body, potentially accepting malformed cards.  
   where: spirit/run/js/nodeCard.js:171  
   why: `cardFrom` includes `ok:true` in the card, but `verify` never checks it, so cards with `ok:false` could be treated as valid.  
   fix: Add `if (body.ok !== true) return null;` before signature verification. *(UNVERIFIED – policy on `ok` not explicit)*  

4. [DESIGN] `ensureDescription` writes a description via `auth.setDescription` without applying `labelRule` normalization/validation, unlike `setDescription`.  
   where: spirit/run/js/nodeCard.js:256  
   why: Auto‑generated descriptions bypass the same checks that manual descriptions undergo, risking over‑length or illegal characters.  
   fix: Use `setDescription` (or apply `labelRule.describeProblem` and `labelRule.normalize`) before saving. *(UNVERIFIED – cannot see `auth.setDescription` internals)*  

5. [DESIGN] Comment lines 84‑89 describe a security issue (signature not covering card text) that no longer applies after the card‑signing implementation, causing confusion.  
   where: spirit/run/js/nodeCard.js:84  
   why: The comment suggests a relay could rewrite a card in flight, but the card is now signed over its fields, making that statement outdated and misleading.  
   fix: Update the comment to reflect that the card fields are signed and cannot be altered without breaking verification.  

6. [DESIGN] `asks` rejects any request containing an `app` field, even if it also carries a description request, potentially breaking legitimate API calls.  
   where: spirit/run/js/nodeCard.js:72  
   why: The early return `if (!parsed || parsed.app) return false;` prevents processing of packets that include both `app` and `body.card`, which may be valid description requests.  
   fix: Adjust logic to only reject when `parsed.app` is present without a description request, e.g., `if (!parsed || (parsed.app && !(parsed.body && parsed.body.card))) return false;`.
