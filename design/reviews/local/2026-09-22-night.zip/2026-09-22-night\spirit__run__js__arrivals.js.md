# spirit/run/js/arrivals.js

Model gpt-oss:120b, 1 slice(s), 9.7 min, 6431 tokens out.

## Lines 1–249

1. [REGRESSION] `traffic.taken` is called with a single hash string instead of an array, which may fail to mark the row as taken and cause duplicate deliveries. where: spirit/run/js/arrivals.js:214; why: In the backlog path `traffic.taken` receives an array (`backlog.map(...)`), implying the API expects an array; here a string (`message.hash`) is passed, and if the API rejects it the error is swallowed, leaving the row un‑taken and replayable; fix: Pass an array, e.g. `traffic.taken([message.hash])`. UNVERIFIED  

2. [DESIGN] The `message` object is reused for all subscribers, allowing a subscriber to mutate it and affect subsequent handlers. where: spirit/run/js/arrivals.js:200; why: `note` creates a single `message` and passes the same reference to each subscriber in the loop; a malicious or buggy subscriber could alter the object, contaminating later deliveries; fix: Clone the message for each subscriber, e.g. `subscribers.slice().forEach(fn => fn(Object.assign({}, message)))`.
