# spirit/run/js/envSecrets.js

Model gpt-oss:120b, 1 slice(s), 16.5 min, 7074 tokens out.

## Lines 1–71

1. [REGRESSION] Unsanitized environment variable values can be inserted directly into request headers, enabling header‑injection attacks.  
   where: spirit/run/js/envSecrets.js:66  
   why: `source[varName]` is returned unchanged and may contain CR/LF or other malicious characters that break HTTP header syntax.  
   fix: Sanitize the value (e.g., strip or encode CR/LF) before returning it.

2. [DESIGN] Host comparison is case‑sensitive, causing false‑negative allowance checks when entry hosts contain uppercase letters.  
   where: spirit/run/js/envSecrets.js:48  
   why: `targetHost` is lower‑cased (`host`) but `e.host` is used as‑is, so `"Example.com"` in the config will never match `"example.com"` from the request.  
   fix: Compare `e.host.toLowerCase() === host`.

3. [DESIGN] Method list matching is case‑sensitive, which may reject allowed methods if the entry’s `methods` array uses a different case.  
   where: spirit/run/js/envSecrets.js:49  
   why: `verb` is upper‑cased, but `e.methods` may contain lower‑case strings, causing `indexOf` to fail.  
   fix: Normalize `e.methods` entries to upper‑case (or perform a case‑insensitive check).

4. [UNVERIFIED] The expected shape of `proxyList.DEFAULTS.entries` is assumed but not validated here.  
   where: spirit/run/js/envSecrets.js:38  
   why: If the defaults lack required fields (`key`, `host`, `open`, `methods`) the `allowed` logic could error or behave incorrectly.  
   fix: Add runtime validation of each entry’s shape when loading defaults.

5. [UNVERIFIED] Potential client‑side import of this module could expose placeholder logic or attempt to read `process.env`.  
   where: spirit/run/js/envSecrets.js:62‑68  
   why: If bundled into browser code, the module may run in a non‑Node environment, leaking internal implementation details or failing unexpectedly.  
   fix: Guard the module (e.g., throw if `typeof process !== 'object'` or `!process.env`) to ensure it’s only used server‑side.
