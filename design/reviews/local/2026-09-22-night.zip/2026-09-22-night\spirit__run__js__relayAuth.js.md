# spirit/run/js/relayAuth.js

Model gpt-oss:120b, 1 slice(s), 13.5 min, 8667 tokens out.

## Lines 1–579

1. [REGRESSION] Private keys are written to `identity.json` with default file permissions, potentially exposing the secret key to other users.  
   where: relayAuth.js:462‑464  
   why: `fs.writeFileSync` is called without a `mode` option, so the file may be created world‑readable depending on the process umask, violating confidentiality of the node’s identity.  
   fix: Use `fs.writeFileSync(path, data, { mode: 0o600 })` to restrict the file to owner‑only access.

2. [REGRESSION] `setDescription` truncates the description by slicing the string, which can split Unicode surrogate pairs and produce an invalid UTF‑16 string.  
   where: relayAuth.js:453‑456  
   why: The `while` loop uses `next = next.slice(0, -1)`, removing a single UTF‑16 code unit; for characters represented by surrogate pairs (e.g., emojis) this leaves a half‑pair, corrupting the stored description.  
   fix: Truncate using a Unicode‑aware method such as `Array.from(next).slice(0, -1).join('')` or by operating on a `Buffer` of UTF‑8 bytes.

3. [REGRESSION] `sign` does not catch errors from malformed `privateKeyB64`, allowing an exception to crash the process.  
   where: relayAuth.js:303‑306  
   why: `privateKeyFromB64` throws on invalid base64 or malformed key data; `sign` forwards the exception uncaught, which can terminate the node.  
   fix: Wrap the signing call in `try { … } catch { return null; }` and return `null` on failure.

4. [REGRESSION] `loadIdentity` validates only `name` and `privateKey`, allowing an identity object missing `publicKey` to be treated as valid.  
   where: relayAuth.js:416‑421  
   why: Subsequent code (e.g., `ensureIdentity`) expects both keys; an absent `publicKey` can cause signature verification to fail silently or lead to inconsistent state.  
   fix: Add `if (!parsed.publicKey) return null;` before returning the parsed object.

5. [REGRESSION] Potential path‑traversal via uncontrolled `rootDir` in file operations.  
   where: relayAuth.js:343, 385, 462 (and other `path.join(rootDir, …)` calls)  
   why: If an attacker can influence `rootDir`, `path.join` may resolve to directories outside the intended `relay-state` tree, allowing read/write of arbitrary files (including keys).  
   fix: Validate that `rootDir` is an absolute path inside a trusted base directory before using it.

6. [DESIGN] `ownerName` returns the first key name from `allow.byName` without deterministic ordering.  
   where: relayAuth.js:548‑551  
   why: `Object.keys` order is not guaranteed across runtimes, leading to nondeterministic UI output or admin decisions when multiple owners exist.  
   fix: Sort the keys (`Object.keys(allow.byName).sort()[0]`) or define an explicit primary‑owner field.

7. [DESIGN] `writeAllowKeys` writes `allow.json` directly, which can leave a partially written file on crash.  
   where: relayAuth.js:388‑393  
   why: A sudden failure during `fs.writeFileSync` may truncate the file, causing `loadAllow` to error on the next start‑up.  
   fix: Write to a temporary file (e.g., `allow.json.tmp`) and rename it atomically after a successful write.
