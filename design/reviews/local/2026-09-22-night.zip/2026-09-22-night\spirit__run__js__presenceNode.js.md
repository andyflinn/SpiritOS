# spirit/run/js/presenceNode.js

Model gpt-oss:120b, 1 slice(s), 15.8 min, 10627 tokens out.

## Lines 1–470

1. **[REGRESSION] Stream objects are never cleared on close, preventing reconnection**  
   **where:** spirit/run/js/presenceNode.js:395 (onClose callback)  
   **why:** When the SSE connection is closed, the stream object remains in `streams[url]`. Subsequent calls to `openTo(url)` see the entry and skip opening a new connection, so the node never restores presence for that relay and can become permanently out‑of‑date.  
   **fix:** After `forget(url)` add `delete streams[url];` (or set it to `null`) to allow a fresh connection.

2. **[REGRESSION] `seedRelay` overwrites existing presence data on reconnect**  
   **where:** spirit/run/js/presenceNode.js:175‑180  
   **why:** On a new stream open `seedRelay(url)` creates a brand‑new set containing only the relay’s own key and the node’s key, discarding any other keys previously learned from that relay. If the stream reconnects without receiving fresh broadcasts, the presence table loses those entries.  
   **fix:** Merge with any existing map instead of replacing it, e.g.:  
   ```js
   const set = byRelay[url] || Object.create(null);
   if (relayKey) set[relayKey] = true;
   if (identity?.publicKey) set[identity.publicKey] = true;
   byRelay[url] = set;
   ```

3. **[DESIGN] `noteSeen` is invoked before the `knows` filter, leaking unknown keys**  
   **where:** spirit/run/js/presenceNode.js:211‑215  
   **why:** The filter (`knows`) determines which keys the node is allowed to display. Calling `noteSeen` beforehand passes every non‑gone key—including those the node has filtered out—to the injected hook, potentially exposing information that should stay hidden.  
   **fix:** Move the `noteSeen` block to after the `knows` check, inside the block that accepts the key.

4. **[REGRESSION] Pending nudge timers survive stream closure and node stop**  
   **where:** spirit/run/js/presenceNode.js:145‑152 (nudgeStatus) and stop at 425‑432  
   **why:** A nudge timer (`setTimeout`) may be pending when a relay’s stream closes or the presence node stops. The timer will later fire and call `onRelayEvent` on a dead context, leading to stray callbacks or memory leaks.  
   **fix:** In `forget(url)` (or in `stop`) clear any pending timer:  
   ```js
   if (nudges[url] && nudges[url].pending) clearTimeout(nudges[url].pending);
   delete nudges[url];
   ```

5. **[REGRESSION] `statusByRelay` and `nudges` maps are not reset on `stop`**  
   **where:** spirit/run/js/presenceNode.js:425‑432 (stop) – statusByRelay defined at 135, nudges at 142  
   **why:** Stopping the presence node should leave no stale state. Leftover entries keep old status data and pending nudge objects, causing incorrect reports if the node is started again.  
   **fix:** Add `statusByRelay = Object.create(null); nudges = Object.create(null);` at the end of `stop`.

6. **[DESIGN] Use of `var` for local objects in event handlers**  
   **where:** spirit/run/js/presenceNode.js:363‑366 (`var row = {}`) and 389‑392 (`var ev = {}`)  
   **why:** `var` is function‑scoped and hoisted, which can lead to accidental reassignments and is outdated style. `const`/`let` provide block scoping and clearer intent.  
   **fix:** Replace `var row = {};` with `const row = {};` and `var ev = {};` with `const ev = {};`.

7. **[REGRESSION] Uncaught exceptions from `openStream` may crash the process**  
   **where:** spirit/run/js/presenceNode.js:280‑283 (the call to `openStream`)  
   **why:** If `openStream` throws synchronously (e.g., malformed URL), the exception propagates uncaught, terminating the node.  
   **fix:** Wrap the call in a try‑catch block:  
   ```js
   try {
     streams[url] = openStream({ ... });
   } catch (e) {
     /* log or ignore, but do not crash */
   }
   ```

8. **[UNVERIFIED] `sseClient.connect` may internally use `EventSource`/`fetch`, violating the “no fetch/EventSource” rule**  
   **where:** spirit/run/js/presenceNode.js:35 (default `openStream`) and usage at line 280  
   **why:** AGENT.md forbids any component from directly using `fetch`, `XMLHttpRequest`, or `EventSource`. If `sseClient.connect` implements the inbound half by creating an `EventSource` or calling `fetch`, it would breach this rule. The implementation of `sseClient` is not visible here, so we cannot verify compliance.  
   **fix:** Ensure `sseClient.connect` is part of the approved `peerPost` interface or replace it with a wrapper that respects the rule, e.g., a `peerPost.openStream` method that abstracts the transport.
