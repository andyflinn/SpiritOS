# spirit/run/js/peerPost.js

Model gpt-oss:120b, 2 slice(s), 37.9 min, 25546 tokens out.

## Lines 1–844

1. [REGRESSION] Unvalidated `relayUrl` allows apps to direct signed requests to arbitrary hosts, bypassing the intended relay‑only communication model and leaking the node’s identity.  
   file:spirit/run/js/peerPost.js:546‑410; why: `post(relayUrl, …)` accepts any string and later passes it to the injected `request` without checking that it is a known relay; a malicious app could supply an external URL.  
   fix: validate `relayUrl` against the node’s configured relay list before calling `request`.

2. [REGRESSION] Duplicate request hashes overwrite existing waiting entries, causing the original promise to never resolve and leaking resources.  
   file:spirit/run/js/peerPost.js:634‑644; why: `waiting[hash] = { … }` overwrites any existing entry for the same hash; if the same request is sent again before the first resolves, the first promise is lost.  
   fix: check `if (waiting[hash]) return Promise.reject(new Error('duplicate request'))` or reuse the existing promise instead of overwriting.

3. [DESIGN] No size limit on outbound `text` permits arbitrarily large messages, enabling memory/CPU exhaustion and large signed payloads being sent to relays.  
   file:spirit/run/js/peerPost.js:552‑554; why: the only validation is that `text` is a non‑empty string; there is no upper bound on length.  
   fix: enforce a maximum `text.length` (e.g., `if (text.length > MAX_TEXT_BYTES) return Promise.resolve({ok:false,status:413,error:'text too large'});`).

4. [DESIGN] `unknownHits` map can grow without bound because entries for sporadic unknown senders are never removed once they have a single recent request.  
   file:spirit/run/js/peerPost.js:236‑239; why: cleanup only deletes a key when its timestamp array becomes empty; a sender that sends a request once per minute will keep its entry forever, leading to unbounded memory growth.  
   fix: periodically prune `unknownHits` keys older than `UNKNOWN_WINDOW_MS` or cap the map size with LRU eviction.

5. [DESIGN] No inbound rate‑limiting for known senders; the floor only applies to unknown senders, allowing a compromised known key to flood the node with requests.  
   file:spirit/run/js/peerPost.js:815‑826; why: after `verdict !== 'known'` the floor check is skipped, so any request from a known sender bypasses all throttling.  
   fix: apply a separate per‑known‑sender rate limit or enforce a global inbound request cap.

## Lines 845–1167

1. [REGRESSION] onArrival is invoked for “known” (held) senders, leaking un‑admitted messages to apps.  
   where: spirit/run/js/peerPost.js:971‑973  
   why: The condition `verdict === 'known' || verdict === 'admit'` treats a held sender (`known`) as admitted, violating the rule “APPS SEE ADMITTED SENDERS ONLY”.  
   fix: Change the condition to `if (verdict === 'admit' && onArrival) {`.

2. [REGRESSION] `admitted` flag incorrectly includes “known” verdicts, causing logs to label held packets as admitted.  
   where: spirit/run/js/peerPost.js:892‑901  
   why: `var admitted = verdict === 'known' || verdict === 'admit';` marks a held packet (`known`) as admitted; subsequent `note` entries therefore mis‑represent the packet’s status, breaking the semantics of “admitted” vs “held”.  
   fix: Set `var admitted = verdict === 'admit';` and, if needed, add a separate `held: verdict === 'known'` flag in the note.

3. [DESIGN] Separate “held” and “admitted” status in logs and API instead of overloading `admitted`.  
   where: spirit/run/js/peerPost.js:892‑901  
   why: Overloaded `admitted` makes it hard to distinguish a packet that is pending human decision from one that is already handed to an app, reducing observability and risking UI mis‑behaviour.  
   fix: Extend the note payload to include both `admitted: verdict === 'admit'` and `held: verdict === 'known'`.
