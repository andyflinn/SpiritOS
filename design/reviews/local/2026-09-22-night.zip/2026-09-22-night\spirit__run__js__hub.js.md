# spirit/run/js/hub.js

Model gpt-oss:120b, 4 slice(s), 47.5 min, 28326 tokens out.

## Lines 1–831

1. [REGRESSION] Blocked contacts are treated as “known” and bypass the front‑door filter, allowing them to send messages despite being blocked.  
   where: hub.js:602  
   why: `frontDoor` checks `listenSet(rootDir)[key]` which includes all contacts, not filtering out rows marked blocked, so a blocked peer returns “known” instead of being dropped.  
   fix: modify `frontDoor` to return `'drop'` when `contactBook.isBlocked(key)` (or equivalent) is true.

2. [REGRESSION] `writeUnknownPolicy` does not catch errors from `fs.writeFileSync` or `fs.renameSync`, so an I/O failure will throw and crash the process.  
   where: hub.js:503‑504  
   why: The file‑write operations are unwrapped; any filesystem error propagates uncaught, violating robustness expectations.  
   fix: wrap the write and rename calls in a `try { … } catch (e) { return false; }` block.

3. [DESIGN] Unused import `peerSearch` creates dead code and unnecessary module loading.  
   where: hub.js:353  
   why: `var peerSearch = require('./peerSearch');` is never referenced, adding load overhead and confusion.  
   fix: remove the require line.

4. [DESIGN] `keyTail` returns the last six Base64 characters of a public key, which is not spoken‑safe and leaks key information; a more appropriate representation (last 30 bits encoded in Crockford base32) is documented but not implemented.  
   where: hub.js:355‑357  
   why: Current tails expose predictable key fragments and conflict with the design note that a better “spoken‑safe” tail is needed.  
   fix: replace `keyTail` with a function that extracts the last 30 bits of the raw key bytes and encodes them in Crockford base32.

5. [DESIGN] Heavy synchronous filesystem I/O (e.g., in `bytesHeldByPeer` and `unknownPolicy`) blocks the Node event loop and can degrade performance under load.  
   where: hub.js:199 (bytesHeldByPeer) and hub.js:527 (unknownPolicy)  
   why: Synchronous `fs.readdirSync`, `fs.readFileSync`, etc., are called on each request, preventing the server from handling other I/O while waiting.  
   fix: refactor these functions to use asynchronous `fs.promises` APIs and cache results where appropriate.

## Lines 832–1611

1. [REGRESSION] handlePeer treats any unknown action as “accept”, unintentionally adding contacts. This bypasses intent checks and can be abused to insert peers.  
   where: hub.js:1500  
   why: The else clause defaults to contactBook.accept for any action not explicitly “block” or “unblock”, so malformed URLs or typo actions are accepted as valid contacts.  
   fix: Add a whitelist check for allowed actions and return 400 for unknown actions before processing.

2. [REGRESSION] handlePeer’s “block” path adds a new contact row without checking memory limits, risking overflow of the contact book.  
   where: hub.js:1455  
   why: When blocking a key not present, contactBook.hold creates a row regardless of shadow(rootDir).roomToAdd, which may exceed the configured memory cap.  
   fix: Verify shadow(rootDir).roomToAdd(publicKey) before calling contactBook.hold and reject with 507 if full.

3. [REGRESSION] handlePost does not enforce a payload size limit before sending to a relay, contrary to the design comment that size limits must be enforced before leaving the machine.  
   where: hub.js:1014  
   why: outgoingPayload simply converts any input to a string and never checks its byte length, allowing oversized messages to be transmitted.  
   fix: Add a length check (e.g., if (Buffer.byteLength(text, 'utf8') > MAX_PAYLOAD) fail with 413.

4. [DESIGN] outgoingPayload always returns ok:true; the error‑handling branch for wrapped.ok is dead code.  
   where: hub.js:948  
   why: The function never produces a false ok, so the surrounding conditional in handlePost is unnecessary and obscures intent.  
   fix: Simplify outgoingPayload to return only the text string and remove the ok wrapper.

5. [DESIGN] systemPayload is defined but never used in this file, adding unused code.  
   where: hub.js:962  
   why: The function returns a JSON string for system messages but no callers reference it, increasing maintenance surface.  
   fix: Delete the systemPayload function.

6. [DESIGN] handleContact still fetches the entire relay census to confirm a single key, wasting bandwidth and request budget.  
   where: hub.js:1558  
   why: The comment notes the full‑census fetch is unnecessary; the node could query the relay for the specific key instead, reducing load.  
   fix: Replace the census request with a targeted “/api/relay/peer?key=...” call that returns only the needed row.

## Lines 1612–2390

1. [REGRESSION] Unvalidated URL used in `relayRequest` enables SSRF and bypasses the `peerPost` interface. where: spirit/run/js/hub.js:2332  
   why: The handler reads a `url` from the request body (line 2301) and directly calls `relayRequest(url, 'GET', '/api/relay/key', null)` without checking that the URL belongs to a known relay or uses a safe scheme. This allows arbitrary external GET requests and violates the rule that all communications must go through `peerPost`. UNVERIFIED: the implementation of `relayRequest` is not shown, so it may bypass the interface.  
   fix: Validate `url` against the list of pinned relays (e.g., via `ownerBadge.configuredUrls` or `relayKeys.pinned`) and route the request through `peerPost` (e.g., a signed `router.post`) instead of a raw GET.

## Lines 2391–2491

NOTHING FOUND
