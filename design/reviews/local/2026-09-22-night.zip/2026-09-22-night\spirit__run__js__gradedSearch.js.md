# spirit/run/js/gradedSearch.js

Model gpt-oss:120b, 1 slice(s), 16.1 min, 10368 tokens out.

## Lines 1–743

1. [DESIGN] merge inflates bucket slots, breaking the fixed‑slot design; where: spirit/run/js/gradedSearch.js:666; why: The code multiplies the base slot count by the number of sources (`wide.slots = n * ((sources && sources.length) || 1);`), allowing unbounded growth of bucket capacity, which can exhaust memory and violates the design that the search bucket has a fixed size (32 slots).; fix: set `wide.slots = n;` (use the base slot count without multiplication).

2. [DESIGN] maxBytes limit uses character count instead of byte count, violating byte‑max guarantee; where: spirit/run/js/gradedSearch.js:712; why: The size check `if (JSON.stringify(next).length > opts.maxBytes)` counts characters, not actual UTF‑8 bytes, so rows with multibyte characters can exceed the intended byte limit; this defeats the contract that `bucket.serialize` respects a byte maximum.; fix: replace `JSON.stringify(next).length` with `Buffer.byteLength(JSON.stringify(next), 'utf8')`.
