# spirit/run/js/buildStamp.js

Model gpt-oss:120b, 1 slice(s), 10.6 min, 6834 tokens out.

## Lines 1–145

1. [REGRESSION] Blocking execFileSync blocks the Node event loop at module load and can stall the process (up to 4 seconds or longer if git hangs). where: spirit/run/js/buildStamp.js:33‑40; why: `execFileSync('git', …)` is synchronous; a slow or failing git call delays startup and can be used for denial‑of‑service on production nodes; fix: replace with an async `execFile` call and make `resolve` async or reduce the timeout and handle failures gracefully.  

2. [DESIGN] Inconsistent stamp object shape – `fromGit` does not include `untracked`, while `fromFile` does, so callers might receive `undefined` for `untracked`. where: spirit/run/js/buildStamp.js:58 (and 66‑73 for `fromFile`); why: varying property sets can cause runtime errors or logic bugs when code expects `stamp.untracked`; fix: add `untracked: 0` to the object returned by `fromGit`. UNVERIFIED.  

3. [DESIGN] Root‑directory validation – functions accept `rootDir` untrusted and compute `repoRoot` via `path.join`, which could lead to directory‑traversal or execution of git in unexpected paths. where: spirit/run/js/buildStamp.js:78‑81; why: ensuring `rootDir` is an absolute path prevents potential information‑leak or DOS if malicious code calls the API; fix: validate `rootDir` with `path.isAbsolute` or `path.resolve` before use. UNVERIFIED.
