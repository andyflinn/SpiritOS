# spirit/run/js/router.js

Model gpt-oss:120b, 1 slice(s), 16.1 min, 10859 tokens out.

## Lines 1–465

[REGRESSION] Unlimited `carry` objects can consume arbitrary memory, enabling a DoS.  
file:router.js:343; why: `pending[hash]` stores `carry` without any size check; a malicious requester could send a huge payload that lives until the entry expires, exhausting RAM.  
fix: add a max byte/size limit for `carry` and reject oversize payloads.

[REGRESSION] Default option handling uses logical OR, preventing zero values and allowing invalid numbers (NaN, negative) to bypass limits.  
file:router.js:156‑162; why: `var max = opts.max || DEFAULT_MAX;`, `var perTarget = opts.maxPerTarget || DEFAULT_PER_TARGET;`, `var ttlMs = opts.ttlMs || DEFAULT_TTL_MS;` treat falsy values as absent, so `max=0` cannot be set and `max=-1` yields a negative capacity, causing immediate “router full”. Non‑numeric strings become `NaN`, disabling the cap.  
fix: replace each with `var max = (opts.max !== undefined) ? opts.max : DEFAULT_MAX;` (and similarly for `perTarget` and `ttlMs`).

[DESIGN] The router’s global capacity (`max`, default 256) can be exhausted by many distinct requesters, enabling a Sybil‑style denial‑of‑service despite per‑requester caps.  
file:router.js:157; why: `Object.keys(pending).length >= max` limits total in‑flight entries, but an attacker can create many unique requester keys each staying under their per‑requester cap, filling the table and blocking legitimate traffic.  
fix: add a global per‑requester‑group limit or a rate‑limit on new distinct requesters.

[REGRESSION] `cancel()` does not purge expired entries before acting, so stale entries may be cancelled or linger unintentionally.  
file:router.js:376‑381; why: `cancel` checks `pending[hash]` without calling `sweep()`, so an entry whose TTL has passed remains and may be incorrectly cancelled, and the router retains dead entries until another sweep occurs.  
fix: call `sweep()` at the start of `cancel`.

[REGRESSION] `capsFrom` ignores `Number` objects, treating them as non‑numeric and falling back to defaults.  
file:router.js:79‑88; why: `typeof given === 'number'` only matches primitive numbers; `new Number(5)` is an object, so caps default to `DEFAULT_PER_REQUESTER` instead of the intended value, causing unexpected caps.  
fix: coerce with `Number(given)` or check `typeof given === 'object' && typeof given.valueOf() === 'number'`.
