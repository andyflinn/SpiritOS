# spirit/run/js/presence.js

Model gpt-oss:120b, 1 slice(s), 8.6 min, 5376 tokens out.

## Lines 1–283

1. [REGRESSION] `evictIdlest` never clears the hit‑timestamp history for evicted identities, so a later reconnect can be blocked by stale rate‑limit data.  
   where: presence.js:173‑176  
   why: after closing a sink the entry in `hits` remains, causing `rateOk` to see old timestamps and reject the next connection from that id.  
   fix: add `delete hits[id];` after `delete openedAt[id];`.

2. [REGRESSION] `disconnect` does not remove the hit‑timestamp record for the disconnected id, leading to the same stale rate‑limit problem on reconnection.  
   where: presence.js:191‑196  
   why: `hits[id]` persists after the sink is removed, so the next connection may be denied by the per‑minute limit.  
   fix: add `delete hits[id];` before returning true.

3. [DESIGN] Capacity check uses `Object.keys(sinks).length` on every connect, incurring O(N) work and allocating a new array each time.  
   where: presence.js:145  
   why: with many concurrent connections this repeated key enumeration can degrade performance.  
   fix: maintain a simple `var count = 0;` that is incremented/decremented on connect/disconnect/evict.

4. [DESIGN] Registry structures (`sinks`, `hits`, `openedAt`) are plain objects; using `Map` would avoid prototype‑pollution, give O(1) size queries, and make iteration clearer.  
   where: presence.js:75‑81  
   why: `Object.create(null)` sidesteps prototype but still lacks built‑in size and iteration helpers; `Map` is more appropriate for key‑value stores.  
   fix: replace each with `new Map()` and adjust access (`set`, `get`, `has`, `delete`, `size`).

5. [DESIGN] `connect` returns HTTP status 403 for missing `id` or `sink`, which semantically means “Forbidden” rather than “Bad Request”.  
   where: presence.js:140  
   why: callers receiving 403 may misinterpret the failure as an auth issue; 400 better reflects malformed input.  
   fix: change `{ ok: false, status: 403 }` to `{ ok: false, status: 400 }`.
