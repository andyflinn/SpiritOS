# spirit/run/js/seenPeers.js

Model gpt-oss:120b, 1 slice(s), 10.0 min, 6464 tokens out.

## Lines 1–336

1. [REGRESSION] spirit/run/js/seenPeers.js:162 – the store may already exceed `maxBytes` from a previous run, but `createSeenPeers` never calls `sweep()` after loading `rows`, so the byte cap isn’t enforced until a later `note`, `size`, or `roomToAdd` call.  
   fix: add `sweep();` right after `var rows = store.seen;`.

2. [DESIGN] spirit/run/js/seenPeers.js:222‑226 – `note` always writes `label: label` (empty string when `what.label` is missing), which could overwrite an existing label if `nodeStore.put` does not treat blank fields as “no‑op”. This risks losing learned labels, contrary to the “greedy” rule. UNVERIFIED  
   fix: only include `label` in the `put` object when a non‑empty label is supplied.

3. [DESIGN] spirit/run/js/seenPeers.js:281 – `forget` is exported and calls `rows.forget`, which likely deletes both the peer entry and its shadow routes. Exposing this permits external code to drop shadow routes when a contact is deleted, violating the rule that shadow routes must survive contact deletion. UNVERIFIED  
   fix: remove `forget` from the public API (or make it internal‑only).
