# spirit/run/js/nodeStore.js

Model gpt-oss:120b, 1 slice(s), 18.3 min, 12374 tokens out.

## Lines 1–626

1. [REGRESSION] Stale timestamp can overwrite newer `seen` values, causing older data to replace newer and potentially evict recent peers.  
   where: spirit/run/js/nodeStore.js:355  
   why: The `put` upsert sets `seen = excluded.seen` unconditionally, so a later call with an older timestamp can downgrade the stored `seen` value, breaking recency‑based eviction and ranking.  
   fix: Change the `seen` assignment to keep the larger timestamp, e.g. `seen = MAX(excluded.seen, seen)`.

2. [REGRESSION] Stale `told` timestamps can overwrite newer route timestamps, degrading route ranking and eviction logic.  
   where: spirit/run/js/nodeStore.js:290  
   why: The `putRoute` upsert sets `told = excluded.told` without comparison, allowing older `told` values to replace newer ones, which affects ordering (`ORDER BY rank ASC, told DESC`) and may drop good routes.  
   fix: Update the clause to keep the newer timestamp, e.g. `told = MAX(excluded.told, seen_routes.told)`.

3. [REGRESSION] `markBook` clears blocked rows, unintentionally removing user‑set blocks when syncing the address book.  
   where: spirit/run/js/nodeStore.js:389  
   why: The `unmarkBook` statement resets `blocked = 0` for rows where `blocked = 1`, so a book sync erases explicit block markings, weakening privacy/security.  
   fix: Remove `blocked = 0` from the `unmarkBook` update, preserving existing block flags.

4. [DESIGN] Allowing `maxRoutes` to be overridden via `opts` can let callers disable route capping, leading to unbounded growth of the route table.  
   where: spirit/run/js/nodeStore.js:102, 474  
   why: `maxRoutes` is set from `opts.maxRoutes` without validation; a malicious or buggy caller could pass a huge number or zero, bypassing the intended three‑route limit and exhausting storage.  
   fix: Enforce `maxRoutes = Math.max(0, Math.min((opts && opts.maxRoutes) || MAX_ROUTES, MAX_ROUTES))` and ignore overrides that exceed the constant.
