# spirit/run/js/deviceAuth.js

Model gpt-oss:120b, 1 slice(s), 6.9 min, 4201 tokens out.

## Lines 1–279

1. [REGRESSION] Insecure file permissions when writing device.json.  
   where: spirit/run/js/deviceAuth.js:112  
   why: The file is written with `fs.writeFileSync` without a mode, so it inherits the process umask (often 022) and may be readable by other users, exposing the enrolment password stored in plaintext. UNVERIFIED (actual umask unknown).  
   fix: Use `fs.writeFileSync(tmp, JSON.stringify(body, null, 2), { mode: 0o600 })` to restrict permissions.

2. [REGRESSION] Silent error handling in `load()` can silently reset the password.  
   where: spirit/run/js/deviceAuth.js:89  
   why: `load()` catches any error (missing file, permission denied, malformed JSON) and returns an empty document, causing `ensurePassword()` to generate a new password without alerting the operator, potentially losing the original password.  
   fix: Log the error and rethrow or propagate it instead of returning `emptyDoc()`.

3. [DESIGN] Module mixes pure utility functions with stateful file‑system functions while being loaded on relays.  
   where: spirit/run/js/deviceAuth.js:8  
   why: The file is loaded on relays for pure functions (`keyToUrl`, `keyFromUrl`, `parseKeyRow`) but also exports `load`, `save`, `generatePassword`, etc., which write to `device.json`. If called on a relay, this violates the rule that `device.json` must never be written on a `--relay`. UNVERIFIED (actual calls on relays not visible here).  
   fix: Split pure functions into a separate module and keep stateful functions in a node‑only module.
