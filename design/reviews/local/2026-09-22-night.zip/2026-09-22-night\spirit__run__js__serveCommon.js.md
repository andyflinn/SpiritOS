# spirit/run/js/serveCommon.js

Model gpt-oss:120b, 1 slice(s), 10.5 min, 6524 tokens out.

## Lines 1–324

1. [REGRESSION] `sendFile` reads arbitrary file paths without any safety check, enabling directory‑traversal or arbitrary file disclosure.  
   where: serveCommon.js:78  
   why: The function directly calls `fs.readFile(filePath)` using the caller‑provided path and serves the raw contents, with no validation that the path resides within a permitted directory. An attacker could cause the server to expose sensitive files.  
   fix: Resolve `filePath` against a trusted base directory and verify the resolved path is inside that base before reading.

2. [DESIGN] `portFromArgs` does not validate that the parsed value is a proper numeric port, allowing NaN or out‑of‑range values that can crash or misconfigure the server.  
   where: serveCommon.js:70  
   why: It uses `Number(...)` on the argument and returns the result even if it is NaN or zero; callers may pass this directly to `server.listen`, leading to runtime errors or unintended listening ports.  
   fix: After parsing, check `Number.isInteger(port) && port > 0 && port <= 65535`; return `null` if the check fails.

3. [REGRESSION] `refuseListenError` attaches an `'error'` listener each time it is called, which can result in multiple listeners on the same server and cause memory‑leak warnings or duplicate error handling.  
   where: serveCommon.js:297  
   why: The exported function may be invoked for each server instance or on re‑initialisation, adding a new listener without removing previous ones; Node will warn about possible listener leaks and the same error could be logged multiple times.  
   fix: Add the listener only once (e.g., use `server.once('error', …)` or guard with `if (server.listenerCount('error') === 0)`).

4. [DESIGN] `readJsonBody` builds the request body by concatenating strings (`body += chunk`), which creates many intermediate strings and can be inefficient.  
   where: serveCommon.js:162  
   why: Each data chunk is turned into a string and concatenated, causing extra allocations before the size limit is reached; using a Buffer array and `Buffer.concat` would be more memory‑efficient.  
   fix: Collect chunks in an array of Buffers, track `seen` as before, and `Buffer.concat(chunks)` after the stream ends.

5. [DESIGN] `parseRequestPath` trusts the raw `Host` header when constructing a URL, which could be abused for host‑header injection if the hostname is later used for logging or redirects.  
   where: serveCommon.js:262  
   why: The code uses ``new URL(req.url, \`http://${req.headers.host || 'localhost'}\`)`` without validating `req.headers.host`; a malicious header could affect the resulting URL object.  
   fix: Validate `req.headers.host` against an allow‑list of expected hostnames or fallback to a known safe host before constructing the URL.
