# spirit/run/js/trafficLog.js

Model gpt-oss:120b, 1 slice(s), 9.5 min, 5470 tokens out.

## Lines 1–537

[REGRESSION] Traffic‑log read APIs (`read`, `arrivals`, `ownerEvents`, `byHash`, `taken`, `historyOf`) are not blocked when the module is instantiated in relay mode, allowing a relay to read the permanent, payload‑full log – a direct violation of the rule “this module is the worst thing in the system on a relay”. file:spirit/run/js/trafficLog.js:283‑285 (note’s guard) and file:spirit/run/js/trafficLog.js:166‑176, 414‑426, 440‑456, 462‑470, 482‑511 (read functions). Fix: add `if (relayMode) return []` (or throw) at the start of each read function, or return a stub API when `relayMode` is true.  

[REGRESSION] `readAll` (and all callers) load the entire traffic log into memory (`fs.readFileSync` → `raw.split('\n')`). Because the log is unbounded, a large node can exhaust RAM and crash the process. file:spirit/run/js/trafficLog.js:128‑152 (readAll) and file:spirit/run/js/trafficLog.js:166‑176 (historyOf). Fix: implement a streaming line‑by‑line reader (e.g., `readline` interface) and process rows incrementally.  

[REGRESSION] `append` performs a race‑prone “read‑tail‑then‑write” sequence. Concurrent calls can both decide a newline is needed (or not) and produce duplicate or missing newlines, corrupting the JSON‑lines format. file:spirit/run/js/trafficLog.js:181‑209 (append). Fix: always write a leading newline unconditionally (or use a file lock) so the newline logic is atomic.  

[REGRESSION] All public functions assume a valid `rootDir`. If `createTrafficLog` is called with a falsy `rootDir`, `logPath`/`legacyPath` receive `undefined`, producing paths like `"undefined/relay-state/traffic.jsonl"` and causing misleading file operations or silent failures. file:spirit/run/js/trafficLog.js:128‑133, 166‑176, 414‑426, 440‑456, 462‑470, 482‑511. Fix: early‑return or throw if `!rootDir` in each API method.  

[DESIGN] The traffic log is designed to grow without bound (see comments 85‑96). Without any retention or pruning, disk usage can eventually fill the node’s storage, causing service failure. file:spirit/run/js/trafficLog.js:85‑96. Fix: add an optional sliding‑window retention policy (e.g., prune entries older than N days) that runs periodically.  

[DESIGN] All file I/O in this module is synchronous (`fs.readFileSync`, `fs.appendFileSync`), blocking the event loop on every packet write and on each read of the full log. On busy nodes this can cause noticeable latency. file:spirit/run/js/trafficLog.js:128‑152, 181‑209. Fix: replace synchronous calls with their asynchronous counterparts (`fs.promises.readFile`, `fs.promises.appendFile`) and adjust callers accordingly.
