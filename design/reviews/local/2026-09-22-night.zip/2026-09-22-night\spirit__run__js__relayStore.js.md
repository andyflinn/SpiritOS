# spirit/run/js/relayStore.js

Model gpt-oss:120b, 1 slice(s), 13.2 min, 8556 tokens out.

## Lines 1–564

1. [REGRESSION] `compact` closes **all** open stores with `closeAll()` and never re‑opens them, leaving the relay without a usable DB after a VACUUM (concurrent requests will hit a closed DB). file:155‑164; why: `closeAll()` shuts every cached connection, then VACUUM runs on a fresh connection that is closed again – the original store objects remain with a closed `db`, so any later DB operation throws. fix: after VACUUM, re‑open the store (e.g. call `open(rootDir)` to restore connections) before returning. UNVERIFIED  

2. [DESIGN] `openReadOnly` returns a full store that still exposes write methods (`members.put`, `invites.add`, etc.) which will throw on a read‑only SQLite connection if mistakenly used. file:67‑71; why: callers receive a store with write APIs but the underlying DB is opened with `{ readOnly: true }`; invoking any write causes a runtime error. fix: return a read‑only wrapper that only includes read methods (or strip write APIs). UNVERIFIED  

3. [DESIGN] `normLabel` uses loose equality `label == null` instead of strict checks. file:60‑62; why: `==` coerces values like `0` or `false` to `null`, potentially normalising unintended inputs to an empty string. fix: replace with `label === null || label === undefined ? '' : label`.  

4. [DESIGN] `memberByLabel` treats any falsy `limit` as `2`, hiding extra matches when callers pass `0` or other falsy values. file:366‑368; why: `limit || 2` forces a default even when a caller explicitly wants zero or a falsy limit, leading to unexpected results. fix: use `limit != null ? limit : 2`.  

5. [REGRESSION] `importLegacy` renames legacy files with `fs.renameSync` without error handling; a rename failure (e.g. cross‑device) will throw and abort startup, leaving the system in an inconsistent state. file:541‑543; why: uncaught exception from `renameSync` can crash the process and prevent the relay from starting. fix: wrap each rename in `try { … } catch (e) { /* log and continue */ }`. UNVERIFIED
