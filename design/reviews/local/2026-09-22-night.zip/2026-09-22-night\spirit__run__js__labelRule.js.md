# spirit/run/js/labelRule.js

Model gpt-oss:120b, 1 slice(s), 11.2 min, 7539 tokens out.

## Lines 1–255

1. [REGRESSION] `spokenOk` accepts non‑string values because it only checks truthiness before testing the regex. This can cause numbers or other objects to be treated as valid spoken tokens, leading to unintended token acceptance.  
   where: spirit/run/js/labelRule.js:141  
   why: `return !!word && SPOKEN_RE.test(word);` coerces any truthy non‑string to a string for the regex test; e.g., `spokenOk(123)` returns true.  
   fix: Change to `return typeof word === 'string' && SPOKEN_RE.test(word);`

2. [REGRESSION] `graphemeCount` falls back to counting code points when `Intl.Segmenter` is unavailable, which can incorrectly reject labels containing combined emojis on older runtimes.  
   where: spirit/run/js/labelRule.js:88  
   why: Without `Intl.Segmenter`, `Array.from(s).length` counts Unicode code points, so a single grapheme like “👩‍💻” (multiple code points) may exceed `LABEL_MAX_GRAPHEMES` even though it is one visual character.  
   fix: Implement a proper grapheme‑cluster fallback (e.g., use a simple regex or a small library) instead of `Array.from(s).length`.

3. [REGRESSION] `normalize` collapses *all* whitespace (`\s`), including newline characters, which unintentionally alters multi‑line description fields.  
   where: spirit/run/js/labelRule.js:119  
   why: `return s.replace(/\s+/g, ' ').trim();` replaces line breaks with a space, losing intended line breaks in node descriptions.  
   fix: Use a separate `normalizeLabel` that only collapses spaces (`/ +/g`) for labels, leaving descriptions untouched.

4. [DESIGN] Top‑level `var` declarations (e.g., `LABEL_MAX_BYTES`, `SEGMENTER`, `ENCODER`) can be reassigned and become globals in non‑module browsers, risking name collisions and accidental mutation.  
   where: spirit/run/js/labelRule.js:51  
   why: `var` is function‑scoped and, when this script runs as a plain script, creates properties on `window`; immutable constants should use `const`.  
   fix: Replace all `var` with `const` (or `let` where mutable) and, if needed, wrap the file in an IIFE or ES module. **UNVERIFIED**

5. [DESIGN] The module attaches `RULE` to `window.spiritLabelRule` but also leaves other `var`‑declared identifiers in the global namespace, which may clash with other scripts.  
   where: spirit/run/js/labelRule.js:250  
   why: Exporting via `window` is intentional, yet the additional top‑level vars pollute the global scope, violating encapsulation.  
   fix: Encapsulate the whole file in a closure and expose only `RULE` on `window` (or use an ES module). **UNVERIFIED**
