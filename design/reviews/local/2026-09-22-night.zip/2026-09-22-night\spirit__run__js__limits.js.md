# spirit/run/js/limits.js

Model gpt-oss:120b, 1 slice(s), 7.5 min, 4436 tokens out.

## Lines 1–196

[REGRESSION] fitsWrapped and fitsWrappedReply ignore the fixed wire overhead, allowing wrapped payloads that exceed the true envelope limit and causing 413 errors on downstream relays. spirit/run/js/limits.js:154‑159, 167‑172; the functions compare the inner JSON length directly to PAYLOAD_MAX, but the final envelope will also contain the 246‑byte overhead (from, to, sig, scaffolding). fix: change the comparisons to `JSON.stringify(...).length + WIRE_OVERHEAD <= PAYLOAD_MAX` (or subtract WIRE_OVERHEAD from PAYLOAD_MAX).

[REGRESSION] limits API is exposed as a mutable global (`window.spiritLimits = limitsApi`), allowing any client script to tamper with security‑critical constants at runtime. spirit/run/js/limits.js:194‑195; mutable globals can be overwritten, potentially raising limits and enabling denial‑of‑service attacks. fix: assign a frozen object – e.g., `window.spiritLimits = Object.freeze(limitsApi)`.

[DESIGN] all limit constants are declared with `var`, permitting reassignment and leaking them into function scope; they should be immutable. spirit/run/js/limits.js:70‑78 (and subsequent var declarations); using `const` (or `Object.defineProperty`) prevents accidental mutation and clarifies intent. fix: replace each `var` with `const`.
