# spirit/run/js/proxyList.js

Model gpt-oss:120b, 1 slice(s), 9.7 min, 6031 tokens out.

## Lines 1–216

1. [REGRESSION] Gate does not enforce key‑allowlist or method restrictions, allowing any key to reach any host unless explicitly closed.  
   where: spirit/run/js/proxyList.js:184  
   why: `gate` only checks for a global open flag and for entries marked closed; it never verifies that the supplied key is listed for the requested host nor that the request method matches an entry’s `methods` array, defeating the proxy’s security intent.  
   fix: Add logic in `gate` to require a matching entry for the key/host and to enforce allowed methods before returning `{ ok: true }`.

2. [REGRESSION] Unhandled filesystem errors on `save` can crash the node process.  
   where: spirit/run/js/proxyList.js:135  
   why: `allow`, `remove`, and `setOpen` invoke `save(rootDir, list)` without try/catch; if `fs.mkdirSync`, `fs.writeFileSync`, or `fs.renameSync` fail (e.g., permission denied, disk full) the exception propagates and terminates the server, compromising reliability.  
   fix: Wrap each `save` call in a try/catch block and return an error object on failure instead of throwing.

3. [DESIGN] Hostname validation regex is too permissive, allowing invalid hostnames.  
   where: spirit/run/js/proxyList.js:62  
   why: `HOST_NAME` is defined as `/^[a-z0-9.-]{1,253}$/`, which permits leading/trailing hyphens, consecutive dots, and other patterns that violate RFC 952/1123; malformed hosts could be stored and later cause proxy misrouting or security confusion.  
   fix: Replace `HOST_NAME` with a stricter pattern (or use a hostname validation library) that enforces RFC‑compliant hostnames.
