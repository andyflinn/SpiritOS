# spirit/run/js/peerFile.js

Model gpt-oss:120b, 1 slice(s), 10.8 min, 7058 tokens out.

## Lines 1–125

1. [REGRESSION] Reversibility broken for characters with code 0xFF (255) – the encoder writes “ff” for a single‑byte 0xFF, but the decoder treats any “ff” as the start of a multi‑byte marker, causing loss or failure to decode.  
   where: spirit/run/js/peerFile.js:50,64‑70  
   why: encode → `out += PEER_FILE_HEX.charAt((code>>4)&0xf)+PEER_FILE_HEX.charAt(code&0xf);` outputs “ff”; decode → `if (byte===0xff){ … }` interprets it as a marker, so a legitimate 0xFF byte cannot be round‑tripped, violating rule 2 (Reversible).  
   fix: use a distinct escape prefix (e.g. “fe”) for >0xFF codes and encode a literal 0xFF as “ff00”.

2. [DESIGN] Un‑sanitized `extension` argument allows path‑traversal or illegal characters in generated filenames.  
   where: spirit/run/js/peerFile.js:88‑92  
   why: the function concatenates `extension` directly to the hex name (`PEER_FILE_PREFIX + name + ext`); a caller could pass “../../evil” or “. /..” and cause the file to be created outside the intended directory, breaking the “one path segment” guarantee.  
   fix: validate that `extension` starts with “.” and contains no path‑separator characters before concatenation.

3. [DESIGN] `peerFileNameFromKey` does not verify that the supplied key is a base64‑encoded public key, permitting arbitrary strings that may break injectivity or reversibility.  
   where: spirit/run/js/peerFile.js:35‑53  
   why: any string (including characters >0xFF) is accepted; non‑base64 input can produce ambiguous encodings (see issue 1) and violates the expectation that keys are Ed25519 SPKI base64.  
   fix: add a check `if (!/^[A-Za-z0-9+/=]+$/.test(publicKey)) return ''` before encoding.

4. [DESIGN] Redundant function name `peerFileFileName` reduces clarity; a single “File” is unnecessary.  
   where: spirit/run/js/peerFile.js:87‑92  
   why: the name repeats “File” twice, making the API less readable and prone to misuse; a clearer name improves maintainability.  
   fix: rename the function to `peerFileName` and update the export object accordingly.

5. [UNVERIFIED] Presence of this module in the `oneDoor.js` census (required by AGENT.md) cannot be confirmed from the file alone.  
   where: spirit/run/js/peerFile.js:1‑125  
   why: AGENT.md mandates every file be listed in the census; without viewing `spirit/test/oneDoor.js` we cannot verify compliance.  
   fix: ensure `peerFile.js` is listed in `spirit/test/oneDoor.js` with the correct count.
