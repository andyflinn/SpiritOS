# spirit/run/js/kernel.js

Model gpt-oss:120b, 2 slice(s), 31.6 min, 21002 tokens out.

## Lines 1–845

1. [REGRESSION] `scanFolder` uses undefined `entry.parentPath`, breaking directory traversal and file listings.  
   where: spirit/run/js/kernel.js:463‑468  
   why: `fs.readdirSync` returns Dirent objects that lack a `parentPath` property, causing `path.resolve(entry.parentPath, …)` and `path.join(entry.parentPath, …)` to resolve incorrectly and skip or mis‑resolve sub‑folders.  
   fix: replace `entry.parentPath` with the `dirPath` argument when building `dirFull`, `dirRelative`, and `subfolder`.

2. [REGRESSION] `createScopedFs.safeName` does not reject Windows absolute paths or backslashes, allowing path‑traversal on Windows.  
   where: spirit/run/js/kernel.js:761‑765  
   why: The check only blocks “..” and leading “/”; a path like `C:\evil\file.js` or `subdir\..\evil.js` bypasses the guard and `path.join` treats it as an absolute path, escaping the app’s root.  
   fix: extend `safeName` to reject backslashes and patterns matching a Windows drive letter (e.g., `/^[a-zA-Z]:[\\/]/`).

3. [DESIGN] Browser‑side file helpers (`loadFile`, `statFile`, `getAnnotations`) use synchronous XMLHttpRequest, blocking the UI thread.  
   where: spirit/run/js/kernel.js:621‑630, 688‑698, 706‑716  
   why: Synchronous XHR freezes the page while waiting for a response, degrading user experience and violating modern web best‑practices.  
   fix: replace the sync XHR calls with asynchronous `fetch` (or async XHR) returning a Promise.

4. [REGRESSION] `checkStaleness` does not catch errors from `fs.statSync`, causing uncaught exceptions when the target file is missing.  
   where: spirit/run/js/kernel.js:521‑528  
   why: If `fullPath` does not exist, `fs.statSync` throws, breaking any caller that expects a result object.  
   fix: wrap the `fs.statSync` call in a try/catch and treat missing files as stale (return `{ stale:true, newRecord:… }`).

5. [REGRESSION] `hashFileContents` reads files with `fs.readFileSync` without error handling, throwing on missing or unreadable files.  
   where: spirit/run/js/kernel.js:494‑496  
   why: An absent or inaccessible file causes an uncaught exception, potentially crashing the process.  
   fix: surround the read with try/catch and return `null` (or a sentinel) on error.

6. [REGRESSION] Use of `EventSource` for job subscription violates the AGENT.md rule prohibiting `EventSource`.  
   where: spirit/run/js/kernel.js:809‑832  
   why: Directly opening an SSE stream bypasses the mandated `peerPost`‑based communication layer and is explicitly disallowed.  
   fix: replace the `EventSource` implementation with periodic polling via `fetch` (or integrate it into the existing `peerPost` API).

7. [DESIGN] `DEBUG` is hard‑coded to `true`, causing noisy logging in production.  
   where: spirit/run/js/kernel.js:21  
   why: Constant verbose output can leak internal state and hurts performance; it should be toggled per environment.  
   fix: set `DEBUG` based on an environment variable or configuration flag (e.g., `const DEBUG = process.env.DEBUG === 'true'`).

## Lines 846–1146

1. [REGRESSION] Direct use of XMLHttpRequest bypasses the required peerPost interface, breaking the “All comms go through peerPost” rule and exposing unsigned requests.  
   where: spirit/run/js/kernel.js:852‑896  
   why: The start, list, cancel, and delete methods each create a raw XMLHttpRequest to “/api/spirit”, which circumvents the signed‑request mechanics of peerPost, creating an insecure attack surface.  
   fix: Refactor these methods to call peerPost (e.g., spirit.core.peerPost) instead of using XMLHttpRequest.

2. [DESIGN] Duplicate icon constants STOP_BUTTON and STOP cause naming collision and potential misuse of the orange‑circle glyph.  
   where: spirit/run/js/kernel.js:1055, 1115  
   why: STOP is defined as the orange circle (🟠) while STOP_BUTTON holds the proper stop‑button glyph (⏹️); callers using ICON.STOP may receive the wrong icon, as noted in the comment.  
   fix: Rename STOP_BUTTON to STOP_BUTTON (or keep it) and either remove the STOP alias or repurpose it with a distinct name to avoid conflict.

3. [DESIGN] Inconsistent HTTP‑status handling in jobs.list compared with other job methods.  
   where: spirit/run/js/kernel.js:872‑878 (list) vs. 858‑862 (start) and 890‑894 (cancel)  
   why: jobs.list only accepts status === 200, whereas other methods accept any 2xx; a 201/204 response would erroneously reject jobs.list.  
   fix: Change jobs.list to use if (xhr.status >= 200 && xhr.status < 300) for success.

4. [DESIGN] Missing network‑error handling on XMLHttpRequest instances.  
   where: spirit/run/js/kernel.js:852‑896 (all XHR calls)  
   why: No xhr.onerror or xhr.ontimeout handlers are set, so connection failures do not reject the Promise and may leave callers hanging.  
   fix: Add xhr.onerror and xhr.ontimeout to reject(new Error('network error')).

5. [DESIGN] Unprotected JSON.parse on server responses may throw on malformed JSON.  
   where: spirit/run/js/kernel.js:860‑862, 876‑878, 891‑892, 907‑908  
   why: Direct JSON.parse without try/catch can raise an exception, breaking the Promise chain and potentially leaking stack traces.  
   fix: Wrap each JSON.parse in try / catch and reject on parse error.
