# spirit/run/js/relayRequest.js

Model gpt-oss:120b, 1 slice(s), 9.4 min, 6265 tokens out.

## Lines 1–95

1. [REGRESSION] file:spirit/run/js/relayRequest.js:73‑78; why: `Object.assign` merges `extraHeaders` after the default headers, so a caller can override the critical `Host` header and bypass the server’s host‑validation logic; fix: Strip or ignore a `Host` entry in `extraHeaders` before merging.  
2. [REGRESSION] file:spirit/run/js/relayRequest.js:73‑78; why: The same merge allows overriding `Content-Type` and `Content-Length`, which can cause mismatched payload lengths or content‑type spoofing; fix: Disallow overriding of `Content-Type` and `Content-Length` in `extraHeaders`.  
3. [DESIGN] file:spirit/run/js/relayRequest.js:38‑40; why: `isLoopbackHost` only recognises `localhost`, `127.0.0.1`, and `::1`; it misses IPv6‑mapped loopback forms like `::ffff:127.0.0.1`, causing valid lab relays to be rejected; fix: Extend the check to include IPv6‑mapped loopback addresses.  
4. [DESIGN] file:spirit/run/js/relayRequest.js:63; why: URL is built by naïve string concatenation (`relayUrl + pathname`), which can produce malformed URLs (double slashes, lost query); fix: Use `new URL(pathname, relayUrl)` and pass that to `assertRelayUrl`.  
5. [DESIGN] file:spirit/run/js/relayRequest.js:37,42,60‑62, etc.; why: The code uses `var` declarations, which are function‑scoped and hoisted, reducing clarity and safety; fix: Replace `var` with `const` or `let` as appropriate.  
6. [DESIGN] file:spirit/run/js/relayRequest.js:60; why: No validation of the `method` argument allows arbitrary strings that could be used for request‑smuggling attacks; fix: Validate `method` against a whitelist (e.g., GET, POST, PUT, DELETE, PATCH).  
7. [DESIGN] file:spirit/run/js/relayRequest.js:61‑87; why: No request timeout is set, so a non‑responsive relay can hang the Promise indefinitely, leaking resources; fix: Add a timeout (e.g., `req.setTimeout(15000, () => reject(new Error('timeout')))`).  
8. [UNVERIFIED] file:spirit/run/js/relayRequest.js:1‑95; why: Cannot confirm from this excerpt that the file is listed in the `oneDoor.js` census required by the test discipline; fix: Ensure `relayRequest.js` is added to the census in `spirit/test/oneDoor.js`.
