# spirit/run/js/relay.js

Model gpt-oss:120b, 6 slice(s), 85.1 min, 51243 tokens out.

## Lines 1–798

1. [DESIGN] reloadAllow never invoked; stale allow data may persist.  
   file:711‑713  
   why: `allow` is loaded at startup via `auth.loadAllow`, but the defined `reloadAllow` function is never called, so updates to `allow.json` are not reflected at runtime, potentially leaving permission data out‑of‑date.  
   fix: call `reloadAllow()` after any change to `allow.json` or expose an endpoint that triggers it.  

2. [REGRESSION] rate‑limit bucket can retain empty keys, causing memory leak for < 1000 keys.  
   file:736‑747  
   why: `rateOk` only sweeps the bucket (removing empty keys) when `Object.keys(bucket).length > RATE_KEY_SWEEP_AT`. If the total key count stays below the threshold, empty buckets are never cleaned, allowing indefinite growth of dead entries.  
   fix: always prune empty keys after filtering, e.g. `if (list.length === 0) delete bucket[k];` in `rateOk`.  

3. [REGRESSION] reliance on `Date.now()` for expirations may break when system clock changes.  
   file:735‑747, 395‑407, 428‑429  
   why: Both rate limiting (`rateOk`) and the meter (`meterNote`, `meterRead`) compute time windows using `Date.now()`. Sudden clock adjustments (NTP, manual changes) can cause premature expiry or indefinite retention, breaking rate limits and metrics.  
   fix: replace `Date.now()` with a monotonic timer such as `process.hrtime.bigint()` for interval calculations.  

4. [REGRESSION] `reconfigure` read path leaks detailed system metrics to callers.  
   file:574‑632  
   why: When called with no `ramLimitMB`/`discLimitMB` fields, `reconfigure` returns internal data (free/total RAM, disc free space, margins, etc.). If the endpoint is not strictly admin‑only, this exposes sensitive operational information.  
   fix: restrict the detailed `room` and `roll` fields to authorized admin callers or omit them from the public response.

## Lines 799–1600

1. [REGRESSION] Typo in constant name causes a ReferenceError, breaking partner availability checks.  
   where: spirit/run/js/relay.js:1195  
   why: `partnerLive` returns `!(missed && now - missed < PARTNER_QUILT_MS)`, but the correct constant is `PARTNER_QUIET_MS`. The misspelled identifier is undefined, leading to a runtime error whenever `partnerLive` is invoked.  
   fix: Change `PARTNER_QUILT_MS` to `PARTNER_QUIET_MS`.

2. [DESIGN] Partner URL is not validated, allowing malformed or malicious URLs.  
   where: spirit/run/js/relay.js:986‑987  
   why: The code trims the URL and strips trailing slashes but does not verify that it is a well‑formed HTTP/HTTPS URL. An attacker could supply an invalid URL that later causes errors or is logged insecurely.  
   fix: Add `try { new URL(at); } catch { return { ok: false, status: 400, error: 'invalid partner URL' }; }` before accepting the URL.

3. [DESIGN] `claimAttempt` assumes a `seen` object is always provided, which can cause a TypeError.  
   where: spirit/run/js/relay.js:1404‑1408  
   why: The function writes `seen.label = n; seen.invite = onInvite;` without checking if `seen` is defined. If the caller omits this argument, the code throws, breaking the claim flow.  
   fix: Insert `if (!seen) seen = {};` before assigning to `seen`.

## Lines 1601–2441

1. [REGRESSION] renameSelf may leave `allow.json` and the members table out of sync on partial failure, locking out the owner. file:spirit/run/js/relay.js:2269; why: the code writes `allow.json` first then updates the member row; if the subsequent `store.members.put` fails (e.g. disk full) the owner name changes but the row stays unchanged, preventing the owner from authenticating. fix: perform the allow‑file write and the member update atomically inside a `guardWrite` transaction and roll back on error.  

2. [REGRESSION] `store.members.put` in renameSelf is not wrapped in `guardWrite`, so a disc‑full error throws uncaught and can crash the relay. file:spirit/run/js/relay.js:2276; why: `guardWrite` converts SQLite “readonly” or full‑disk errors into a structured response; without it the exception propagates out of the request handler. fix: wrap the call in `guardWrite('rename', () => store.members.put({publicKey:…, publicLabel:…, claimedAt:…}))`.  

3. [REGRESSION] `forgetPeer`’s `store.transaction` is unguarded; a write failure (e.g. full disc) will raise an unhandled exception and may terminate the process. file:spirit/run/js/relay.js:2331; why: the transaction writes to `members` and `partners`; on failure the error bubbles up because no `try/catch` or `guardWrite` is used. fix: wrap the transaction in `guardWrite('forget', () => store.transaction(() => { … }))`.  

4. [DESIGN] `deviceOffer` allows any authenticated identity to enroll a device; it does not restrict enrollment to the relay owner. file:spirit/run/js/relay.js:1960; why: without an owner check a malicious peer could bind arbitrary devices to the relay, violating the security model that only the owner should manage devices. fix: add an `if (!isOwner(who)) return Promise.resolve({ok:false,status:403,error:DEVICE_REFUSAL});` guard before proceeding. UNVERIFIED (cannot confirm from this snippet whether the route is already owner‑restricted).  

5. [DESIGN] `post()` sends outbound requests via `presentNow.send` instead of the mandated `peerPost` interface, potentially bypassing the centralized signing/hash/dispatch logic. file:spirit/run/js/relay.js:2066; why: the system rule states “All comms go through `peerPost`”; using `presentNow.send` may sidestep signature verification and hash‑based routing, breaking that invariant. fix: replace the `presentNow.send` call with a call to `peerPost.post(toKey, signedMessage)` (or delegate to the existing `peerPost` implementation). UNVERIFIED (cannot verify that `presentNow.send` is outside the public HTTP interface).

## Lines 2442–3225

1. [REGRESSION] Potential revocation of all invites when `body.revoke.label` is missing or empty, causing `invites.revokeInvite` to be called with an empty string. This could wipe all pending invites if the function treats an empty label as a wildcard.  
   where: spirit/run/js/relay.js:3184  
   why: The code does not validate that `revokedLabel` is non‑empty before invoking `invites.revokeInvite`; an empty label may be interpreted as “revoke all”.  
   fix: Add a check that `revokedLabel` is non‑empty before calling `invites.revokeInvite`.  
   UNVERIFIED

2. [REGRESSION] `sendAnswer` silently returns without sending a reply when the node's private key is missing, leaving the requester hanging and causing a denial‑of‑service.  
   where: spirit/run/js/relay.js:3220  
   why: The function exits on `if (!mine || !mine.privateKey) return;` without sending any response, so callers never receive a reply.  
   fix: Send an error reply (e.g., status 500) instead of silently returning.

3. [DESIGN] Search result size check uses `JSON.stringify(...).length`, which measures characters not actual byte length, risking packets that exceed the byte‑size limit.  
   where: spirit/run/js/relay.js:3027  
   why: `MATCH_BUDGET` is defined in bytes; using character count can mis‑estimate size for multibyte characters, potentially violating the payload limit.  
   fix: Replace the check with `Buffer.byteLength(JSON.stringify(tryRow), 'utf8')`.

4. [REGRESSION] The `mint` call relies on a global `allow` variable without confirming it is defined, which could throw a runtime error if `allow` is undefined.  
   where: spirit/run/js/relay.js:3202  
   why: `auth.ownerName(allow)` assumes `allow` exists; if it is missing, the call will fail and break the invite‑minting path.  
   fix: Ensure `allow` is loaded (e.g., `var allow = loadAllow();`) before using it.  
   UNVERIFIED

## Lines 3226–4040

1. [REGRESSION] `routeReply` does not resolve partner identities, causing partner replies to be rejected as “no such identity”.  
   where: spirit/run/js/relay.js:3742  
   why: The function uses `deviceIdentity(fromToken)` only; partner replies require `partnerIdentity` resolution, so the signature verification fails and the reply is rejected with 403.  
   fix: Change to `var who = deviceIdentity(fromToken) || partnerIdentity(fromToken);`.

2. [DESIGN] Owner‑event logging for membership actions is missing, violating the rule that owner events must always be recorded.  
   where: spirit/run/js/relay.js:4019‑4040  
   why: Comments state that owner events (e.g., invites, slot claims) should be logged permanently, but the file contains no `ownerEvent` calls, risking loss of audit information.  
   fix: Insert `ownerEvent(...)` calls at each point where membership state changes (e.g., after successful invite acceptance, slot claim, or revocation).

3. [DESIGN] `readMonitorFilter` does not cap the size of the `kinds` array, allowing a malicious caller to supply an arbitrarily large list and potentially exhaust memory.  
   where: spirit/run/js/relay.js:3996‑3999  
   why: The function accepts any length array, maps each entry to a string, and keeps only allowed kinds; an attacker could send a huge array to cause a DoS.  
   fix: Add a check like `if (raw.kinds.length > 10) return null;` (or truncate) before processing. UNVERIFIED

## Lines 4041–4519

NOTHING FOUND
