# spirit/run/js/spiritErrors.js

Model gpt-oss:120b, 1 slice(s), 10.2 min, 6148 tokens out.

## Lines 1–442

1. [REGRESSION] `classify` returns the raw catalogue entry objects (e.g. `BY_CODE[b.code]`) directly. Callers can mutate these shared objects, corrupting the global error catalog and leading to inconsistent error handling. where: spirit/run/js/spiritErrors.js:411 (also 412‑416)  
   why: The returned entry is a mutable reference; any mutation persists across the process. This violates safety expectations for immutable error metadata.  
   fix: return a shallow copy, e.g. `return Object.assign({}, BY_CODE[b.code]);`.

2. [DESIGN] `define` does not enforce uniqueness of error `code`. A later definition with the same code silently overwrites the previous entry, dropping its texts/prefixes and breaking classification. where: spirit/run/js/spiritErrors.js:80  
   why: Without a duplicate check, accidental reuse of a code can erase existing error definitions, causing mis‑classification and loss of diagnostic information.  
   fix: add a duplicate guard, e.g. `if (BY_CODE[code]) throw new Error('duplicate error code: '+code);` before inserting.
