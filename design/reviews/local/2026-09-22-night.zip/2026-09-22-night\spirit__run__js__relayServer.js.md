# spirit/run/js/relayServer.js

Model gpt-oss:120b, 2 slice(s), 36.4 min, 24742 tokens out.

## Lines 1–825

1. [REGRESSION] API responses leak internal error details.  
   where: spirit/run/js/relayServer.js:742 (inside `writePosted`).  
   why: The `writePosted` function includes `error: result.error` (and other internal fields) in the JSON payload sent to clients, potentially exposing implementation‑specific messages or sensitive information.  
   fix: Remove or sanitize the `error` field before serialising the response.

2. [REGRESSION] Unhandled exception when serving static files can crash the relay.  
   where: spirit/run/js/relayServer.js:679 (`common.sendFile(res, path.join(ROOT_DIR, BROCHURE[pathname]));`).  
   why: `common.sendFile` is called without a try/catch; if the file is missing, unreadable, or an I/O error occurs, the exception will propagate and terminate the process, breaking availability.  
   fix: Wrap the call in a try/catch and respond with a 404 (or 500) if the file cannot be sent.

3. [REGRESSION] Potential division‑by‑zero when calculating the Retry‑After header.  
   where: spirit/run/js/relayServer.js:619 (`Math.ceil(60 / relay.presence.perMin) + 5`).  
   why: If `relay.presence.perMin` is ever zero (mis‑configuration or bug), the division yields `Infinity`, causing an invalid header value or a runtime error, breaking the response to the client.  
   fix: Guard against zero, e.g. `const perMin = Math.max(relay.presence.perMin, 1); res.setHeader('Retry-After', String(Math.ceil(60 / perMin) + 5));`.

4. [REGRESSION] No top‑level error handling in the HTTP request handler risks process crash on unexpected exceptions.  
   where: spirit/run/js/relayServer.js:514 (`http.createServer((req, res) => { … })`).  
   why: The entire request‑processing logic is not wrapped in a try/catch; any uncaught exception will bubble up and terminate the Node process, violating the “always‑on” requirement for relays.  
   fix: Enclose the handler body in `try { … } catch (e) { console.error(e); res.writeHead(500); res.end('Internal Server Error'); }`.

5. [UNVERIFIED] Partner stream signature verification may be insufficient.  
   where: spirit/run/js/relayServer.js:586 (`createRelay.streamSignatureFrom(url.searchParams.get('sig'), req.headers)`).  
   why: The security of the SSE `/api/relay/stream` endpoint relies on `streamSignatureFrom` correctly validating the signature; without reviewing that function we cannot confirm it resists forged signatures or replay attacks.  
   fix: Verify that `streamSignatureFrom` performs strict cryptographic checks, rejects malformed or missing signatures, and includes nonce or timestamp validation.

## Lines 826–954

1. [REGRESSION] spirit/run/js/relayServer.js:885; why: The call `require('./relayAuth').loadAllow(ROOT_DIR).mode` is not wrapped in a try‑catch. If `allow.json` is missing, unreadable, or malformed the exception bubbles up and crashes the relay, causing an outage. fix: wrap the call in a try‑catch and handle errors gracefully (e.g., default to safe mode or abort with a clear message).  
2. [REGRESSION] spirit/run/js/relayServer.js:936; why: `relayStore.open(ROOT_DIR).bytes()` is executed without error handling. A corrupted or inaccessible `relay.db` will throw, terminating the process and leading to denial‑of‑service. fix: surround the call with try‑catch and fallback to a safe value or perform a controlled shutdown.  
3. [DESIGN] spirit/run/js/relayServer.js:912; why: The assignment `partnerRouter = require('./peerPost').createPeerPost({ … })` lacks an explicit `let/const` declaration in the visible snippet, potentially creating a global variable and polluting the module namespace, which can cause subtle bugs across modules. fix: add `let partnerRouter;` (or `const`) before the assignment. UNVERIFIED  
4. [DESIGN] spirit/run/js/relayServer.js:838; why: Using `execFileSync` blocks the event loop for up to 2 seconds while invoking `systemctl`. This can delay handling of other requests and degrade responsiveness. fix: replace the synchronous call with `execFile` (async) and handle the result via callbacks or promises.  
5. [DESIGN] spirit/run/js/relayServer.js:853; why: `restartNow` may be called before `goodbyeFn` is assigned at line 872, resulting in a silent no‑op and preventing a legitimate restart request from taking effect. fix: ensure `goodbyeFn` is initialized before exposing `restartNow`, or guard the call with a check.
