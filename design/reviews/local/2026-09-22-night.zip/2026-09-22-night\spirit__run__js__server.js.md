# spirit/run/js/server.js

Model gpt-oss:120b, 3 slice(s), 39.7 min, 24810 tokens out.

## Lines 1–853

1. [REGRESSION] Direct use of `http`/`https` modules for outbound requests in the generic proxy bypasses the mandated `peerPost` interface and violates the rule that no component may reach for `http`, `https`, `fetch`, `XMLHttpRequest` or `EventSource`. file:spirit/run/js/server.js:18,21; why: `handleGenericProxy` creates raw client requests with `http.request`/`https.request`, opening an unsanctioned communication path and sidestepping signed, hashed request handling. fix: Refactor `handleGenericProxy` to route outbound calls through `peerPost` or record an explicit exception.

2. [REGRESSION] The `/api/spirit` (proxy) endpoint skips the request‑size guard, allowing arbitrarily large request bodies. file:spirit/run/js/server.js:669; why: `common.refuseTooBig` is bypassed for `/api/spirit`, so a malicious client can exhaust memory/CPU with huge payloads, causing denial‑of‑service. fix: Apply `common.refuseTooBig` (or an equivalent size limit) to the proxy route.

3. [DESIGN] `handleGenericProxy` does not whitelist HTTP methods, allowing any method (including destructive ones) to be proxied. file:spirit/run/js/server.js:523; why: The `method` field is taken from the request body without validation, so callers can issue DELETE, TRACE, etc., against arbitrary hosts, expanding the attack surface. fix: Validate `method` against an allowed list (e.g., GET, POST, PUT, PATCH) and reject others with 405.

4. [DESIGN] Static file serving depends on `fsPath` for path resolution without visible sanitisation, risking directory‑traversal attacks. file:spirit/run/js/server.js:763‑766; why: If `fsPath` does not correctly normalise `pathname`, a crafted request could access files outside `ROOT_DIR`. UNVERIFIED; fix: Ensure `fsPath` resolves the path securely and rejects any path that escapes `ROOT_DIR`.

## Lines 854–1643

1. [REGRESSION] Swallowed startup errors prevent visibility of critical failures.  
   where: spirit/run/js/server.js:1413  
   why: `presence.start(...).catch(() => {});` silently ignores any error from `presence.start`, leaving the node without presence functionality without a log.  
   fix: replace with `.catch(e => console.error('presence start error:', e));`

2. [REGRESSION] Potential exposure of personal node to the network if the loopback bind host is not used.  
   where: spirit/run/js/server.js:962 (definition) – usage not shown in this slice.  
   why: `const BIND_HOST = '127.0.0.1';` is defined to enforce loopback binding, but the server listen call is not visible; if `server.listen(port)` is used instead of `server.listen(port, BIND_HOST)`, the node would listen on all interfaces, violating the personal‑node security model.  
   fix: ensure `server.listen(port, BIND_HOST)` is used for the HTTP server. UNVERIFIED

3. [REGRESSION] Closure captures `presence` before it is initialized, possibly yielding an empty relay list.  
   where: spirit/run/js/server.js:1165‑1170 (urls function) & spirit/run/js/server.js:1229 (presence assignment)  
   why: The `urls` function returned to `answerer.createAnswerer` references `presence`, which is only assigned later at line 1229; if `answerer` calls `urls()` synchronously during construction, it will see `presence` as undefined and return an empty array, breaking relay discovery.  
   fix: move the `answerer` creation after `presence` is initialized or make `urls` lazily fetch `presence` when first called. UNVERIFIED

4. [REGRESSION] Uncaught exceptions in proxy verb handlers can crash the server.  
   where: spirit/run/js/server.js:1450‑1457 (`proxyVerb` definition)  
   why: `proxyVerb` parses JSON, then calls `work(body)` without a try/catch; if any `work` function (e.g., `proxyList.allow`) throws, the exception propagates and terminates the request handler, potentially bringing down the process.  
   fix: wrap `const out = work(body || {});` in a try/catch and send a 500 error on failure.

5. [DESIGN] Incorrect `Allow` header syntax may confuse HTTP clients.  
   where: spirit/run/js/server.js:942 (POST only) and spirit/run/js/server.js:951 (method not allowed)  
   why: The header values are `'POST /'` and `'GET, POST'`; RFC 7231 expects a comma‑separated list of methods without path components, e.g., `'POST'`. Including a slash can cause clients to misinterpret allowed methods.  
   fix: change to `{ 'Allow': 'POST' }` and `{ 'Allow': 'GET, POST' }` respectively.

6. [REGRESSION] Body‑size limit check occurs after the request body may have already been streamed, allowing large payloads to consume memory before rejection.  
   where: spirit/run/js/server.js:907‑910  
   why: `common.bodyBytes(req)` is evaluated after `peekVerb(req)` which may have already read part of the stream; if the request is larger than `BODY_MAX`, the server may have already buffered data, exposing a DoS vector.  
   fix: enforce size limit while streaming the request, aborting early when the limit is exceeded.

7. [DESIGN] Synchronous contact‑book look‑up in presence `knows` blocks the event loop.  
   where: spirit/run/js/server.js:1232  
   why: `contactBook.byPublicKey(ROOT_DIR, key)` reads from disk synchronously for each presence check, potentially slowing request handling under load.  
   fix: replace with an async version (e.g., `await contactBook.byPublicKeyAsync`) and make `knows` return a promise or cache results.

8. [DESIGN] Requiring the limits module on every request adds unnecessary overhead.  
   where: spirit/run/js/server.js:907‑910 (`require('./limits').BODY_MAX`)  
   why: `require` is executed on each request, causing repeated module resolution.  
   fix: load `const { BODY_MAX } = require('./limits');` once at module top level.

## Lines 1644–1721

1. [REGRESSION] Potential race condition – `process.exit(0)` may terminate the process before asynchronous SSE writes complete.  
   file:1709‑1712  
   why: `sayGoingAway` could perform async writes to SSE streams; calling `process.exit` immediately aborts pending I/O, risking truncated “retry:” messages to clients.  
   fix: make `goodbye` async and `await` `sayGoingAway` (or its returned promise) before invoking `process.exit`.  
   UNVERIFIED  

2. [DESIGN] Magic number for SSE retry delay is hard‑coded (3000 ms).  
   file:1701‑1703  
   why: The retry interval is inlined, making future tuning or configuration difficult and reducing code clarity.  
   fix: define a constant (e.g. `const SSE_RETRY_DELAY_MS = 3000;`) and use it in the `sayGoingAway` call.  

3. [DESIGN] Shutdown handling logic is duplicated inline; should be extracted to a shared module.  
   file:1696‑1715  
   why: Both personal nodes and relays need identical graceful‑shutdown behavior; extracting it reduces duplication and eases maintenance.  
   fix: move the `goodbye` function and signal listeners into a utility module (e.g. `utils/shutdownHandler.js`) and import it.  

4. [DESIGN] No handler for `SIGHUP` (or other reload signals), so graceful shutdown may be missed on systemd reloads.  
   file:1714‑1715  
   why: Systemd can send `SIGHUP` for config reloads; without handling, connected SSE clients won’t receive the shutdown notice.  
   fix: add `process.on('SIGHUP', () => goodbye('SIGHUP'));`.  
   UNVERIFIED
