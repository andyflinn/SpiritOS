# spirit/run/js/peerSearch.js

Model gpt-oss:120b, 1 slice(s), 11.3 min, 7212 tokens out.

## Lines 1–173

1. [REGRESSION] peerSearch.js:100‑101  
   why: `rowsFrom` copies **all** keys from `m.item` into the result row (`Object.keys(m.item).forEach…`). This can inadvertently expose internal or private fields of a peer when rows are sent over the wire, violating the expectation that only public data be shared. UNVERIFIED – cannot confirm from this file whether private fields exist.  
   fix: Filter `m.item` to only whitelist public fields before copying.

2. [REGRESSION] peerSearch.js:151  
   why: The expression `source && source.via == null ? null : source.via` uses loose `== null`, which treats both `null` **and** `undefined` as `null`. Sources with an undefined `via` are therefore classified as “own members”, receiving a full `near` signal weight (1.0) incorrectly and skewing ranking.  
   fix: Replace the check with a strict null comparison: `source && source.via === null ? null : source.via`.
