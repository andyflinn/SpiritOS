# spirit/run/js/postQueue.js

Model gpt-oss:120b, 1 slice(s), 19.6 min, 13914 tokens out.

## Lines 1–476

1. [REGRESSION] `accepts` mis‑calculates available space for background items – it checks the total `bytesHeld` (all classes) against the background quota, which overly restricts background traffic. The rule intends the background share to apply only to background‑class bytes. where: spirit/run/js/postQueue.js:179‑183; why: The condition `bytesHeld + bytes <= room` uses a global byte count, so a queue full of deliberate items can block any background request even though the background quota is still free. fix: Track `bytesHeldBackground` separately and compare `bytesHeldBackground + bytes` to `bytesMax * BACKGROUND_SHARE` for background items.

2. [REGRESSION] `eligible` can return entries whose patience has expired – it never checks the entry’s `until` timestamp, so an expired request may be retried after its budget is spent. where: spirit/run/js/postQueue.js:289‑298; why: The loop skips only sending, in‑flight, and back‑off checks; it does not filter out items where `it.until <= now`, violating the patience limit described in the comments. fix: Add `if (it.until <= now) continue;` before returning the entry.

3. [DESIGN] `add` does not enforce the queue’s byte‑capacity internally – callers must pre‑check `accepts`, otherwise the queue can exceed `QUEUE_BYTES_MAX`. where: spirit/run/js/postQueue.js:186‑205; why: Relying on external checks is error‑prone; a bug in a caller could overflow memory. fix: At the start of `add`, return `null` or throw if `!accepts(item.kind, item.bytes)`.

4. [DESIGN] `eligible` sorts the whole queue on every call – `items.slice().sort(order)` is O(n log n) each lookup, which can become a performance bottleneck for large queues. where: spirit/run/js/postQueue.js:289‑292; why: Frequent scheduling (e.g., every wake‑up) will repeatedly allocate and sort the array, wasting CPU. fix: Maintain a priority queue (heap) keyed by class rank and seq, updating it on add/drop/start/stop.

5. [DESIGN] `pairKey` concatenates `relayUrl` and `toKey` with a NUL (`'\u0000'`) separator, which could clash if either value contains that character. where: spirit/run/js/postQueue.js:169‑172; why: Using a raw separator risks key collisions, breaking back‑off tracking for distinct peers. fix: Encode the pair as JSON (`JSON.stringify({relayUrl,toKey})`) or use `Map` with nested maps.
