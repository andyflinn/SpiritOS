# spirit/run/js/relayKeys.js

Model gpt-oss:120b, 1 slice(s), 14.0 min, 9706 tokens out.

## Lines 1–247

1. [REGRESSION] Unhandled file‑system errors can crash the node.  
   where: spirit/run/js/relayKeys.js:76  
   why: `fs.writeFileSync` and `fs.renameSync` may throw on disk‑full, permission, or concurrent‑write failures; the exception bubbles up and terminates the process, breaking node availability.  
   fix: wrap the write and rename in a try/catch and return false on failure.

2. [REGRESSION] `load` silently discards malformed JSON, erasing all stored relay pins.  
   where: spirit/run/js/relayKeys.js:61  
   why: The catch block returns `{}` for any error, including JSON parse errors, causing loss of trust‑on‑first‑use data without alert, a security regression.  
   fix: log the error and abort initialization (or rethrow) instead of returning an empty object.

3. [REGRESSION] `accept` overwrites an existing entry and drops any stored seat information.  
   where: spirit/run/js/relayKeys.js:196  
   why: When a relay key changes, the function replaces the whole row, removing `row.seat` (claim label and timestamp), breaking persistence of the node’s seat.  
   fix: merge the new fields into the existing row while preserving `row.seat`.

4. [REGRESSION] `seat` returns `undefined` instead of a boolean success flag.  
   where: spirit/run/js/relayKeys.js:122  
   why: The function returns the result of `save` (which returns `undefined`), causing callers to treat a successful seat as a failure.  
   fix: after calling `save`, return `true`.

5. [REGRESSION] `unseat` returns `undefined` instead of a boolean success flag.  
   where: spirit/run/js/relayKeys.js:164  
   why: Same issue as `seat`; the caller receives a falsy value despite the operation succeeding.  
   fix: after calling `save`, return `true`.

6. [DESIGN] Synchronous file I/O blocks the event loop.  
   where: spirit/run/js/relayKeys.js:61 (readFileSync) and 76 (writeFileSync)  
   why: Blocking calls halt all asynchronous work while disk access occurs, degrading node responsiveness.  
   fix: replace with async `fs.promises` methods and `await` them.

7. [DESIGN][UNVERIFIED] Potential race condition when multiple processes invoke `save` concurrently, leading to corrupted `relayKeys.json`.  
   where: spirit/run/js/relayKeys.js:72  
   why: The load‑modify‑save sequence is not atomic; overlapping writes could interleave and corrupt the JSON file.  
   fix: implement a file lock or use an atomic write library to serialize access.

8. [DESIGN][UNVERIFIED] `rootDir` is not validated, allowing path‑traversal if supplied by an attacker.  
   where: spirit/run/js/relayKeys.js:47  
   why: `keysPath` concatenates an unchecked `rootDir` with a fixed sub‑path; a malicious `rootDir` like `"../../etc"` could cause writes outside the intended directory.  
   fix: sanitize `rootDir` to an absolute path within an allowed base directory before joining.

9. [DESIGN] Exporting `keysPath` exposes the internal storage location, enabling code to bypass the `peerPost` interface and read/write private data directly.  
   where: spirit/run/js/relayKeys.js:234  
   why: Direct file access violates the rule that all communications and data handling go through the prescribed interfaces, and it opens a path for unintended usage.  
   fix: remove `keysPath` from `module.exports` or make it a private helper only.
