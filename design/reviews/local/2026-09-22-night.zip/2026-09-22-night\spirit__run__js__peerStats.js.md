# spirit/run/js/peerStats.js

Model gpt-oss:120b, 1 slice(s), 9.7 min, 6252 tokens out.

## Lines 1–165

1. [REGRESSION] Public key is used directly in file path without visible sanitisation, allowing path‑traversal or invalid filenames.  
   where: spirit/run/js/peerStats.js:31  
   why: `statsPath` builds the path with `peerFile.fileName(publicKey)`; if `publicKey` contains “../” or other unsafe characters it can escape `app/contacts`. This breaches the personal‑node isolation guarantee.  
   fix: Validate/sanitise `publicKey` (e.g. allow only base64url chars) before constructing the filename.  
   UNVERIFIED (cannot confirm `peerFile.fileName` sanitises).

2. [REGRESSION] Synchronous file I/O blocks the event loop, risking latency spikes under load.  
   where: spirit/run/js/peerStats.js:57,75‑80  
   why: `fs.readFileSync`, `fs.mkdirSync`, `fs.writeFileSync`, and `fs.renameSync` are blocking calls executed on every inbound/outbound note, which can stall other operations in a single‑threaded Node process.  
   fix: Replace with async `fs.promises` methods (`await fs.readFile`, `await fs.mkdir`, etc.) and adjust callers to handle promises.

3. [REGRESSION] `readRow` silently swallows read and JSON‑parse errors, returning an empty row and masking underlying problems.  
   where: spirit/run/js/peerStats.js:57‑71  
   why: Any filesystem error (e.g., permission denied) or corrupted JSON results in an empty stats row without logging, leading to silent data loss and making debugging difficult.  
   fix: Log the caught error (or rethrow) instead of returning `emptyRow`; propagate the error to the caller.

4. [DESIGN] Exporting `statsPath` leaks internal path construction, exposing a low‑level API that external code could misuse.  
   where: spirit/run/js/peerStats.js:160  
   why: Providing `statsPath` publicly allows callers to build arbitrary file paths under the contacts directory, breaking encapsulation and increasing attack surface.  
   fix: Remove `statsPath` from `module.exports` or keep it private within the module.
