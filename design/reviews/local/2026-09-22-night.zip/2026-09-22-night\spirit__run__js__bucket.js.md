# spirit/run/js/bucket.js

Model gpt-oss:120b, 1 slice(s), 11.3 min, 7202 tokens out.

## Lines 1–191

1. [REGRESSION] Size measurement uses string length instead of actual byte length, potentially exceeding the configured `maxBytes`.  
   where: spirit/run/js/bucket.js:156,164  
   why: The `serialize()` method checks `JSON.stringify(next).length` and returns `bytes: JSON.stringify(out).length`. `String.length` counts UTF‑16 code units, not the UTF‑8 byte size transmitted, so non‑ASCII characters can cause the payload to surpass the limit.  
   fix: Replace length checks with `Buffer.byteLength(JSON.stringify(...), 'utf8')`.

2. [REGRESSION] `serialize()` can throw if `map` returns a non‑JSON‑serializable value (e.g., circular reference), crashing the node.  
   where: spirit/run/js/bucket.js:155‑158,164  
   why: The method unconditionally calls `JSON.stringify(next)` and later `JSON.stringify(out)`. If `row` contains circular references or unsupported types, `JSON.stringify` throws, which is not caught, leading to an uncaught exception and node termination.  
   fix: Wrap `JSON.stringify` calls in try/catch and treat failures as a cut or error.

3. [DESIGN] No validation that `compare` returns a numeric result; a faulty compare may return NaN causing incorrect ordering or eviction.  
   where: spirit/run/js/bucket.js:82,98‑100  
   why: The constructor only checks that `compare` is a function. Later `compare(item, weakest) >= 0` and the binary‑search logic rely on numeric comparisons. If `compare` returns NaN or a non‑number, the bucket may accept inferior items or reject better ones, breaking its contract.  
   fix: Add a runtime check that `compare` returns a finite number for sample items.

4. [DESIGN] Inefficient O(k²) size calculation in `serialize()` due to repeated full `JSON.stringify` of the growing array.  
   where: spirit/run/js/bucket.js:155‑158  
   why: For each item the method creates `next = out.concat([row])` and recomputes `JSON.stringify(next)`. This results in quadratic work relative to capacity (k). While k is small, an incremental byte‑count would reduce CPU usage.  
   fix: Maintain a running byte count (using `Buffer.byteLength`) and add the new row’s size plus separator overhead instead of re‑stringifying the whole array each iteration.
