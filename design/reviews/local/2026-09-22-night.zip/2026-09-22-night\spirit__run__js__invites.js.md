# spirit/run/js/invites.js

Model gpt-oss:120b, 1 slice(s), 7.2 min, 4198 tokens out.

## Lines 1–211

1. [REGRESSION] load returns invite tokens, violating the rule that owner reports must never expose tokens.  
   where: invites.js:42-44  
   why: `load` returns `relayStore.open(rootDir).invites.all()`, which includes the `token` field for every invite; this data can be shown in UI or logged, leaking secret invite tokens.  
   fix: map the rows to omit `token` before returning (e.g., `return rows.map(r=>({label:r.label, expiresAt:r.expiresAt, invitedBy:r.invitedBy}));`).

2. [REGRESSION] add does not validate `opts.expiresAt`, allowing malformed dates that never expire and cause indefinite invite accumulation.  
   where: invites.js:85-88  
   why: The function stores `opts.expiresAt` verbatim; if the value is not a valid ISO date, `Date.parse` later returns `NaN`, making the expiry check always false and preventing `sweepExpired` from ever removing the row. This defeats the design goal that invites are swept.  
   fix: validate `opts.expiresAt` is a parsable future ISO date, otherwise fall back to the computed default expiry.

3. [DESIGN] `normalizeDays` contains a dead branch that is never reachable.  
   where: invites.js:56-60  
   why: After `Math.floor` and the `if (!isFinite(d) || d <= 0) return 7;` guard, `d` is always ≥ 1, so `if (d < 1) return 1;` can never execute, making the code harder to read.  
   fix: remove the unreachable `if (d < 1) return 1;` condition.

4. [DESIGN] Multiple functions repeatedly call `relayStore.open(rootDir)`, causing unnecessary repeated store initialisation.  
   where: invites.js:90, 126, 145, 178 (and similar lines)  
   why: Each call creates a new store handle; caching the store per function call would reduce overhead and improve performance without changing semantics.  
   fix: open the store once at the start of each exported function and reuse the instance for subsequent operations.
