# spirit/run/js/nodeSettings.js

Model gpt-oss:120b, 1 slice(s), 6.0 min, 3509 tokens out.

## Lines 1–141

1. [REGRESSION] Unbounded `cacheMaxMB` allows arbitrarily large values, risking OOM or denial‑of‑service when converted to bytes.  
   where: spirit/run/js/nodeSettings.js:92  
   why: Validation only checks >0 and the floor; no ceiling is enforced, so a malicious or accidental huge number can cause `cacheMaxBytes` to overflow or allocate excessive memory.  
   fix: Add a `MAX_CACHE_MAX_MB` constant and reject or cap values above it.

2. [REGRESSION] Unbounded `searchMemoryRows` permits extremely large row counts, which can exhaust memory during searches.  
   where: spirit/run/js/nodeSettings.js:108  
   why: The code validates only that the value is a whole number ≥0; without an upper limit a huge setting can cause massive in‑memory structures and degrade performance or crash the node.  
   fix: Introduce a `MAX_SEARCH_MEMORY_ROWS` constant and reject or cap values exceeding it.

3. [DESIGN] Exported `filePath` may be used elsewhere to write `node.json`, contradicting the rule that the node never writes this file.  
   where: spirit/run/js/nodeSettings.js:132  
   why: AGENT.md states the file is read‑only; exposing its path publicly encourages other modules to write to it, creating a potential policy breach.  
   fix: Remove `filePath` from module exports (or rename to a private helper).

4. [DESIGN] `load` caches a mutable settings object; callers could mutate it, corrupting the cached configuration for all future loads.  
   where: spirit/run/js/nodeSettings.js:70  
   why: The returned object includes `cacheMaxMB`, `searchMemoryRows`, and `problems`; if any consumer modifies these fields, the cache reflects the change, breaking the guarantee of immutable configuration.  
   fix: Return a deep‑frozen copy (e.g., `Object.freeze({…settings})`) or clone before caching.

5. [DESIGN] `filePath` builds the path from the raw `rootDir` argument while caching uses the resolved absolute path, which can lead to inconsistent reads if callers pass different relative forms.  
   where: spirit/run/js/nodeSettings.js:62‑66  
   why: `load` caches based on `path.resolve(rootDir)` but `filePath` uses the original `rootDir`; different relative inputs that resolve to the same absolute directory will read the file multiple times before the cache hits, violating the “read once” intent.  
   fix: Have `filePath` also use the resolved absolute path (`path.resolve(rootDir)`).
