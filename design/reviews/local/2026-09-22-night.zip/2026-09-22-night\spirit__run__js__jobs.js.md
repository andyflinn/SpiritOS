# spirit/run/js/jobs.js

Model gpt-oss:120b, 1 slice(s), 11.8 min, 8045 tokens out.

## Lines 1–328

1. [REGRESSION] Unrestricted command execution – `startProcessJob` spawns any command with no validation or permission checks.  
   where: jobs.js:204‑210  
   why: `child_process.spawn(command, args …)` receives raw `command`/`args` from the caller; an attacker could run arbitrary binaries, potentially with elevated privileges. The file does not show any authentication or whitelist enforcement (UNVERIFIED).  
   fix: validate `command` against a whitelist and enforce an admin‑only check before spawning.

2. [REGRESSION] Full environment leakage to child processes.  
   where: jobs.js:205‑208  
   why: `Object.assign({}, process.env, …)` copies every environment variable into the child, exposing secrets (e.g., private keys, tokens) to any spawned process.  
   fix: construct a minimal env object containing only safe variables before passing to `spawn`.

3. [REGRESSION] FS‑watcher error handler does not close the watcher, leaving a broken watcher alive.  
   where: jobs.js:179‑185  
   why: On `'error'` the job status is set to `'failed'` but `watcher.close()` is never called, so the watcher may continue emitting errors and waste resources.  
   fix: call `watcher.close()` inside the error handler before updating the job.

4. [DESIGN] `deleteJob` never invokes the job’s cleanup (`_stop`), so resources (watchers, child processes) can stay open after deletion.  
   where: jobs.js:119‑126  
   why: After a terminal job is removed, any associated resource remains running unless the caller used `cancelJob`; deletion alone should also clean up.  
   fix: before `jobsMap.delete(id)`, call `if (job._stop) job._stop();`.

5. [DESIGN] Unlimited SSE listeners – `events.setMaxListeners(0)` disables Node’s leak detection.  
   where: jobs.js:38  
   why: Removing the listener ceiling can hide accidental listener accumulation, leading to unbounded memory growth if connections aren’t correctly removed.  
   fix: set a high but finite limit (e.g., `events.setMaxListeners(256)`) and ensure listeners are always detached.

6. [DESIGN] No quota on job creation; an attacker could flood the system with jobs.  
   where: jobs.js:30‑34 (jobsMap/nextId) and jobs.js:41 (`createJob`).  
   why: `createJob` is callable without any rate‑limit; unlimited jobs can exhaust memory/CPU.  
   fix: enforce a `MAX_JOBS` constant and reject new jobs when the limit is reached.

7. [REGRESSION] File‑watcher job exposes absolute paths, leaking internal directory structure.  
   where: jobs.js:128‑136 (`mapEntry`).  
   why: `fullPath` (and `relativePath` derived from it) are stored in job data and sent to the UI/API, potentially revealing sensitive paths to any user with access.  
   fix: omit `fullPath` from the returned object and sanitize `relativePath` to prevent `..` traversal.

8. [DESIGN] Debounce drops intermediate file‑change events while a timeout is pending.  
   where: jobs.js:163‑173 (`scheduleRescan`).  
   why: While `pending` is set, any further events are ignored, so rapid changes may be missed, causing the UI to become stale.  
   fix: queue the latest event details and always reschedule after each timeout, or use a sliding‑window debounce.

9. [REGRESSION] No error handling around `scanFolder`; an exception will crash the process.  
   where: jobs.js:140 (initial scan) and jobs.js:167 (rescannedFiles).  
   why: If `scanFolder` throws (e.g., permission error), the uncaught exception terminates the server.  
   fix: wrap each `scanFolder` call in `try { … } catch (e) { updateJob(job.id, { status: 'failed', logMessage: String(e) }); }`.

10. [DESIGN] `setMaxListeners(0)` combined with potential missing listener removal may cause memory leaks in long‑running SSE connections.  
    where: jobs.js:38 and any SSE attach/detach (outside this file).  
    why: The comment acknowledges “MaxListenersExceededWarning” but suppresses it; without rigorous detach logic, leaked listeners can accumulate.  
    fix: audit SSE connection handling to guarantee removal and keep a reasonable listener limit.
